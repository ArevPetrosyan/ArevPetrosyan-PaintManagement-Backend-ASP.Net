﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common
{
    public class ApiResult
    {
        public ApiResult()
        {
            IsSuccess = true;
            Message = string.Empty;
        }

        public bool IsSuccess { get; set; }

        public string Message { get; set; }

        public object DataObject { get; set; }

    }
}
