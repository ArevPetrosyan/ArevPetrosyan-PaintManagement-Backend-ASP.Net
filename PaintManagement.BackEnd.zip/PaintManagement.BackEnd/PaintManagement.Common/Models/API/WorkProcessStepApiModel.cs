﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class WorkProcessStepApiModel
    {
        public int WorkProcessStepId { get; set; }

        public int WorkProcessId { get; set; }

        public int StepIndex { get; set; }

        public int PaintId { get; set; }

        public string PaintName { get; set; }

        public int PaintTypeId { get; set; }

        public PaintType PaintTypeName
        {
            get
            {
                return (PaintType)PaintTypeId;
            }
            set
            {
                PaintTypeId = (int)value;
            }
        }

        public int Amount { get; set; }

        public int StatusId { get; set; }

        public bool IsDeleted { get; set; }
    }
}
