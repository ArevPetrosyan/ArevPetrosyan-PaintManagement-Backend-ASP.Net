﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class WorkProcessApiModel
    {

        public int WorkProcessId { get; set; }

        public int OrderItemId { get; set; }

        public string OrderCode { get; set; }

        public int OrderItemAmount { get; set; }

        public string WorkPieceName { get; set; }

        public int Amount { get; set; }

        public DateTime CreateDate { get; set; }

        public int StatusId { get; set; }

        public WorkProcessStatus WorkProcessStatus
        {
            get => (WorkProcessStatus)StatusId;
            set { StatusId = (int)value; }
        }

        public bool IsDeleted { get; set; }

        public int AssignedStaffId { get; set; }

        public string StaffName { get; set; }

        public DateTime WorkProcessStartDate { get; set; }

        public List<WorkProcessStepApiModel> WorkProcessSteps { get; set; }

    }
}
