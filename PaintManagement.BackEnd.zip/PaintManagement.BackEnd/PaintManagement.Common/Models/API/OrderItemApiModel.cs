﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class OrderItemApiModel
    {
        public int OrderItemId { get; set; }

        public int OrderId { get; set; }

        public int WorkPieceId { get; set; }

        public string WorkPieceName { get; set; }

        public int Amount { get; set; }

        public int PaintId { get; set; }

        public string PaintName { get; set; }

        public int PaintTypeId { get; set; }

        public bool IsDeleted { get; set; }

    }
}
