﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class BatchItemApiModel
    {
        public long BatchItemId { get; set; }

        public int BatchId { get; set; }

        public bool IsDeleted { get; set; }

        public int BucketId { get; set; }

        public string BucketBarcode { get; set; }

        public string BucketPaintName { get; set; }

        public int UsedAmount { get; set; }

    }
}
