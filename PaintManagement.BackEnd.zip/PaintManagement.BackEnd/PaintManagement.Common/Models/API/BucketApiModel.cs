﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class BucketApiModel
    {
        public int BucketId { get; set; }

        public int Amount { get; set; }

        public DateTime BestBefore { get; set; }

        public bool IsEmpty { get; set; }

        public int RemainingAmount { get; set; }

        public DateTime ProductionDate { get; set; }

        public string ManufacturerBatchNumber { get; set; }

        public string Barcode { get; set; }

        public bool IsDeleted { get; set; }

        public int PaintId { get; set; }

        public string PaintName { get; set; }

        public uint BucketCount { get; set; }
    }
}
