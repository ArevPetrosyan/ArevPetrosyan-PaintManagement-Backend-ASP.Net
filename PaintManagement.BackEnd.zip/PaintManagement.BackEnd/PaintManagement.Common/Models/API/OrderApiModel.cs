﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class OrderApiModel
    {

        public int OrderId { get; set; }

        public string OrderCode { get; set; }

        public int CustomerId { get; set; }

        public string CustomerName { get; set; }

        public DateTime CreateData { get; set; }

        public int OrderStatusId { get; set; }

        public OrderStatus OrderStatus
        {
            get
            {
                return (OrderStatus)OrderStatusId;
            }
            set
            {
                OrderStatusId = (int)value;
            }
        }

        public DateTime DeliveryDate { get; set; }

        public bool IsDeleted { get; set; }

        public List<OrderItemApiModel> OrderItemApiModelList { get; set; }

    }
}
