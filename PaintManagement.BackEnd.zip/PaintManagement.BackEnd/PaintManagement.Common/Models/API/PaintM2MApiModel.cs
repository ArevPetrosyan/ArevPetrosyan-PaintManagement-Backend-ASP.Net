﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class PaintM2MApiModel
    {
        public int PaintM2MId { get; set; }

        public int MainPaintId { get; set; }

        public int ConnectedPaintId { get; set; }
    }
}
