﻿using PaintManagement.Common.Models.DB.Views;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class BucketApiReportModel : BucketView
    {
        public BucketApiReportModel(BucketView bucketView) : base(bucketView)
        {

        }

        public PaintType PaintTypeName
        {
            get
            {
                return (PaintType)PaintTypeId;
            }
            set
            {
                PaintTypeId = (int)value;
            }
        }

    }
}
