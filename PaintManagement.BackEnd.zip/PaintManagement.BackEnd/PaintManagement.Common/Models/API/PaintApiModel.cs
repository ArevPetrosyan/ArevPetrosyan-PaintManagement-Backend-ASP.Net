﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
   public class PaintApiModel
    {
        public int PaintId { get; set; }

        public int PaintTypeId { get; set; }

        public PaintType PaintTypeName
        {
            get
            {
                return (PaintType)PaintTypeId;
            }
            set
            {
                PaintTypeId = (int)value;
            }
        }

        public string PaintName { get; set; }

        public decimal SolventContent { get; set; }

        public bool IsDeleted { get; set; }

        public int SupplierId { get; set; }

        public string SupplierName { get; set; }

        public string OrderNumber { get; set; }

        public string Color { get; set; }

    }
}
