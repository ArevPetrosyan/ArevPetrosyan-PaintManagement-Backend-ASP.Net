﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.API
{
    public class BatchApiModel
    {
        public int BatchId { get; set; }

        public DateTime CreateDate { get; set; }

        public string BatchBarcode { get; set; }

        public int StaffId { get; set; }

        public string StaffName { get; set; }

        public int StatusId { get; set; }

        public BatchStatus BatchStatus
        {
            get
            {
                return (BatchStatus)StatusId;
            }
            set
            {
                StatusId = (int)value;
            }
        }

        public int WorkProcessStepId { get; set; }

        public int WorkProcessId { get; set; }

        public int WorkProcessStepAmount { get; set; }

        public int StepIndex { get; set; }

        public int PaintId { get; set; }

        public List<BatchItemApiModel> BatchItemApiModelList { get; set; }

    }
}
