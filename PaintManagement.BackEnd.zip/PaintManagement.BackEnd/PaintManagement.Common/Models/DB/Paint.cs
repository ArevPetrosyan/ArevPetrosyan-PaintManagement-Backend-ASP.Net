﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class Paint
    {
        public int PaintId { get; set; }

        public int PaintTypeId { get; set; }

        public string PaintName { get; set; }

        public decimal SolventContent { get; set; }

        public bool IsDeleted { get; set; }

        public int SupplierId { get; set; }

        public string OrderNumber { get; set; }

        public string Color { get; set; }

        public Supplier Supplier { get; set; }

        public ICollection<Bucket> Buckets { get; set; }
    }
}
