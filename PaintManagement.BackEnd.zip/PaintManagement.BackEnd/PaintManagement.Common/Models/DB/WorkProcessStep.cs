﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class WorkProcessStep
    {

        public int WorkProcessStepId { get; set; }

        public int WorkProcessId { get; set; }

        public WorkProcess WorkProcess { get; set; }

        public int StepIndex { get; set; }

        public int PaintId { get; set; }

        public Paint Paint { get; set; }

        public int Amount { get; set; }

        public int StatusId { get; set; }

    }
}
