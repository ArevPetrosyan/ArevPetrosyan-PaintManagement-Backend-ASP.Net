﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class WorkPiece
    {

        public int WorkPieceId { get; set; }

        public string WorkPieceName { get; set; }

        public int CustomerId { get; set; }

        public string WorkPieceDescription { get; set; }

        public bool IsDeleted { get; set; }

        public Customer Customer { get; set; }

    }
}
