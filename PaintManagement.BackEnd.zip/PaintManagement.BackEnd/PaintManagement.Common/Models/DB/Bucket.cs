﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class Bucket
    {
        public int BucketId { get; set; }

        public int Amount { get; set; }

        public DateTime BestBefore { get; set; }

        public bool IsEmpty { get; set; }

        public int RemainingAmount { get; set; }

        public DateTime ProductionDate { get; set; }

        public string ManufacturerBatchNumber { get; set; }

        public string Barcode { get; set; }

        public bool IsDeleted { get; set; }

        public int PaintId { get; set; }

        public Paint Paint { get; set; }

    }
}
