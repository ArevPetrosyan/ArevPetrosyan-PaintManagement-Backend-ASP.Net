﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class Customer
    {
        public int CustomerId { get; set; }

        public string CustomerName { get; set; }

        public string PhoneNumber { get; set; }

        public string Address { get; set; }

        public string Email { get; set; }

        public bool IsDeleted { get; set; }

        ICollection<WorkPiece> WorkPieces { get; set; }

        ICollection<Order> Orders { get; set; }

    }
}
