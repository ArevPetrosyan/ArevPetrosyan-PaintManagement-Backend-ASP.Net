﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class Order
    {
        public int OrderId { get; set; }

        public int CustomerId { get; set; }

        public Customer Customer { get; set; }

        public DateTime CreateDate { get; set; }

        public string OrderCode { get; set; }

        public DateTime DeliveryDate { get; set; }

        public int OrderStatusId { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<OrderItem> OrderItems { get; set; }
    }
}
