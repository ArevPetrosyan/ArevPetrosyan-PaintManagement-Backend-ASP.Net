﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class BatchItem
    {
        public long BatchItemId { get; set; }

        public int BatchId { get; set; }

        public int BucketId { get; set; }

        public Bucket Bucket { get; set; }

        public int UsedAmount { get; set; }

    }
}
