﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB.Views
{
    public class BucketView
    {
        public BucketView(BucketView bucketview)
        {
            SupplierId = bucketview.SupplierId;
            SupplierName = bucketview.SupplierName;
            PaintId = bucketview.PaintId;
            PaintTypeId = bucketview.PaintTypeId;
            PaintName = bucketview.PaintName;
            BucketId = bucketview.BucketId;
            Amount = bucketview.Amount;
            BestBefore = bucketview.BestBefore;
            RemainingAmount = bucketview.RemainingAmount;
            ProductionDate = bucketview.ProductionDate;
            ManufacturerBatchNumber = bucketview.ManufacturerBatchNumber;
            Barcode = bucketview.Barcode;
        }

        public BucketView()
        {

        }

        public int SupplierId { get; set; }

        public string SupplierName { get; set; }

        public int PaintId { get; set; }

        public int PaintTypeId { get; set; }

        public string PaintName { get; set; }

        public int BucketId { get; set; }

        public int Amount { get; set; }

        public DateTime BestBefore { get; set; }

        public int RemainingAmount { get; set; }

        public DateTime ProductionDate { get; set; }

        public string ManufacturerBatchNumber { get; set; }

        public string Barcode { get; set; }
    }
}
