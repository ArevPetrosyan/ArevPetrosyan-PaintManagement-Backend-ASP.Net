﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }

        public int OrderId { get; set; }

        public Order Order { get; set; }

        public int Amount { get; set; }

        public int PaintId { get; set; }

        public Paint Paint { get; set; }

        public int WorkPieceId { get; set; }

        public WorkPiece WorkPiece { get; set; }
    }
}
