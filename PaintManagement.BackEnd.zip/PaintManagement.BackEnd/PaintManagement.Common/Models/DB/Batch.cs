﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class Batch
    {
        public int BatchId { get; set; }

        public DateTime CreateDate { get; set; }

        public int StaffId { get; set; }

        public Staff Staff { get; set; }

        public int WorkProcessStepId { get; set; }

        public WorkProcessStep WorkProcessStep { get; set; }

        public int StatusId { get; set; }

        public string BatchBarcode { get; set; }

        public ICollection<BatchItem> BatchItems { get; set; }

    }
}
