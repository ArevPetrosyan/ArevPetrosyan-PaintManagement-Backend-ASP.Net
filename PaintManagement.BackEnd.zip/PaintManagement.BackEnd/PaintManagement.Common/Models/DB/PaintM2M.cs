﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class PaintM2M
    {
        public int PaintM2MId { get; set; }

        public int MainPaintId { get; set; }

        public int ConnectedPaintId { get; set; }
    }
}
