﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Models.DB
{
    public class WorkProcess
    {
        public int WorkProcessId { get; set; }

        public int OrderItemId { get; set; }

        public OrderItem OrderItem { get; set; }

        public int Amount { get; set; }

        public DateTime CreateDate { get; set; }

        public int StatusId { get; set; }

        public bool IsDeleted { get; set; }

        public int StaffId { get; set; }

        public Staff Staff { get; set; }

        public DateTime WorkProcessStartDate { get; set; }

        public ICollection<WorkProcessStep> WorkProcessSteps { get; set; }

    }
}
