﻿using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Resources;
using System.Text;

namespace PaintManagement.Common.Messages
{

    public static class MessageHandler
    {
        public static void SetMessageCulture(Language language)
        {
            CultureInfo tempCulture = null;
            switch (language)
            {
                case Language.German:
                    tempCulture = new CultureInfo("de-DE");
                    break;
                case Language.English:
                default:
                    tempCulture = new CultureInfo("en-US");
                    break;
            }

            MessageResource.Culture = tempCulture;
        }

    }
}
