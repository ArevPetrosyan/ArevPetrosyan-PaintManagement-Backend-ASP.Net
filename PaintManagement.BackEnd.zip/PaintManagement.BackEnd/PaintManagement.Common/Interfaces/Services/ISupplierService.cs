﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface ISupplierService
    {

        List<Supplier> LoadAllSupplier();

        Supplier LoadSupplierById(int supplierId);

        List<Supplier> LoadActiveSuppliers();

        ApiResult Add(Supplier supplier);

        ApiResult Edit(Supplier supplier);

        ApiResult DeleteBySupplierId(int supplierId);

    }
}
