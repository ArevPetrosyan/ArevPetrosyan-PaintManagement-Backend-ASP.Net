﻿using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IBatchService
    {

        Batch LoadByBatchId(int batchId);

        List<Batch> LoadByStaffId(int staffId);

        List<Batch> LoadActiveByStaffId(int staffId);

        List<Batch> LoadAll();

        ApiResult Add(Batch batch);

        ApiResult Edit(Batch batch);

        ApiResult EditStatus(int batchId, BatchStatus batchStatus);

        ApiResult DeleteByBatchId(int batchId);

    }
}
