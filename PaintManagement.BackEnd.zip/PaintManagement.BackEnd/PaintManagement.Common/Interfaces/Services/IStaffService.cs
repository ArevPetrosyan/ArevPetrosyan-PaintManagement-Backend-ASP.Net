﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IStaffService
    {

        List<Staff> LoadActiveStaff();

        Staff LoadById(int staffId);

        Staff LoadByAuthenticationBarcode(string authenticationBarcode);

        Staff LoadByAuthenticationTagId(string authenticationTagId);

        ApiResult Add(Staff staff);

        ApiResult Edit(Staff staff);

        ApiResult DeleteByStaffId(int staffId);

    }
}
