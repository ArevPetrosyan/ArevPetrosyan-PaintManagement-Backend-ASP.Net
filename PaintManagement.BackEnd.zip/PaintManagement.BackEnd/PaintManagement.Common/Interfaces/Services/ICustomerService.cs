﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface ICustomerService
    {
        List<Customer> LoadAllCustomer();

        ApiResult Add(Customer customer);

        ApiResult Edit(Customer customer);

        ApiResult DeleteByCustomerId(int customerId);

        Customer LoadByCustomerId(int customerId);
        
        List<Customer> LoadActiveCustomers();
    }
}
