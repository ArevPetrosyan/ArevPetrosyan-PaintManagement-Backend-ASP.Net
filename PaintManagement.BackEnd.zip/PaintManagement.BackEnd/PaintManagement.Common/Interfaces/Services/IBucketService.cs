﻿using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Models.DB.Views;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IBucketService
    {

        List<BucketView> LoadActiveBucketByBestBeforeRemainDays(int remainDays);

        Bucket GetByBucketId(int bucketId);

        Bucket GetByBarcode(string barcode);

        List<Bucket> LoadBucketByBatchId(int batchId);

        List<Bucket> LoadAcitveBucketByPaintId(int paintId);

        ApiResult Add(Bucket bucket, uint bucketCount = 1);

        ApiResult Edit(Bucket bucket);

        ApiResult DeleteByBucketId(int bucketId);

    }
}
