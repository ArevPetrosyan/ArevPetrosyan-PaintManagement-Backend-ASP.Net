﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IPaintService
    {

        Paint LoadByPaintId(int paintId);

        List<Paint> LoadConnectedPaintByPaintId(int paintId);

        List<Paint> LoadAcitvePaintBySupplierId(int supplierId);

        List<Paint> LoadActivePaint();

        ApiResult Add(Paint paint);

        ApiResult Edit(Paint paint);

        ApiResult DeleteByPaintId(int paintId);

        ApiResult AddConnectedPaint(PaintM2M paintM2M);

        ApiResult DeleteConnectedPaint(PaintM2M paintM2M);
    }
}
