﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;


namespace PaintManagement.Common.Interfaces.Services
{
    public interface IWorkPieceService
    {
        List<WorkPiece> LoadAllWorkPiece();

        List<WorkPiece> LoadActiveWorkPieces();

        List<WorkPiece> LoadActiveWorkPieceByCustomerId(int customerId);

        WorkPiece LoadById(int workPieceId);

        ApiResult Add(WorkPiece workPiece);

        ApiResult Edit(WorkPiece workPiece);

        ApiResult DeleteByWorkPieceId(int workPieceId);


    }
}
