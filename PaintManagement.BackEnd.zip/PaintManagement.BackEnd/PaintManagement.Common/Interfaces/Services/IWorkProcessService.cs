﻿using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IWorkProcessService
    {
        List<WorkProcess> LoadAll();

        List<WorkProcess> LoadAllActive();

        WorkProcess LoadById(int workProcessId);

        WorkProcess LoadByWorkProcessStepId(int workProcessStepId);

        ApiResult Add(WorkProcess workProcess);

        ApiResult Edit(WorkProcess workProcess);

        ApiResult EditStatus(int workProcessId, WorkProcessStatus workProcessStatus);

        ApiResult DeleteByWorkProcessId(int workProcessId);

        ApiResult DeleteWorkProcessStepByWorkProcessStepId(int workProcessStepId);

        ApiResult DeleteWorkProcessStepByWorkProcessStepIds(List<int> workProcessStepIds);
    }
}
