﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Interfaces.Services
{
    public interface IOrderService
    {

        List<Order> LoadActiveOrders();

        Order LoadOrderById(int orderId);

        List<Order> LoadActiveOrderByCustomerId(int customerId);

        List<Order> LoadActiveOrderByOrderStatusId(int orderStatusId);

        List<Order> LoadActiveOrderByWorkpieceId(int workpieceId);

        List<Order> LoadActiveOrderByPaintId(int paintId);

        ApiResult Add(Order order);

        ApiResult Edit(Order order);

        ApiResult DeleteByOrderId(int orderId);

        ApiResult DeleteOrderItemByOrderItemIds(List<int> orderItemIds);
    }
}
