﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common
{
    public static class GeneralParameter
    {
        public static string ConnectionString { get; set; }
    }
}
