﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Utilities.Enumerations
{
    public enum WorkProcessStatus
    {
        Draft = 1,
        Confirm = 2,
        InProcess = 3,
        Done = 4,
        Cancel = 5
    }
}
