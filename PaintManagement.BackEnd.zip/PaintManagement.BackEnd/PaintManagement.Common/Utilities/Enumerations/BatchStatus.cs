﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Utilities.Enumerations
{
    public enum BatchStatus
    {
        Draft = 1,
        Confirm = 2,
        InProcess = 3,
        Cancel = 4,
        Done = 5,
    }
}
