﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Utilities.Enumerations
{
    public enum Language
    {
        English = 1,
        German = 2
    }
}
