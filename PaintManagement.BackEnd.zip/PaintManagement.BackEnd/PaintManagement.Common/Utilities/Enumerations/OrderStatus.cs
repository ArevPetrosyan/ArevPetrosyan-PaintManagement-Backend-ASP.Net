﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Utilities.Enumerations
{
    public enum OrderStatus
    {
        Draft,
        Confirm,
        InProgress,
        Cancel,
        Done,
    }
}
