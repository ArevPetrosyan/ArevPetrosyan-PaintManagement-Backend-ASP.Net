﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Common.Utilities.Enumerations
{
    public enum PaintType
    {
        Paint = 1,
        Primer = 2,
        Hardener = 3,
        BondingAgent = 4,
        Thinner = 5
    }
}
