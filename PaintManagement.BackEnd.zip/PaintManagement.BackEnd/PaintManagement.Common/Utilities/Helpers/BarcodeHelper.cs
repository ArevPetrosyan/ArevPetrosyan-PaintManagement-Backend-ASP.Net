﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaintManagement.Common.Utilities.Helpers
{
    public static class BarcodeHelper
    {

        public const string BucketBarcodePrefix = "(PB)"; // PaintBucket

        public static string CreateBucketBarcode(Bucket bucket)
        {
            string result = string.Empty;

            result = BucketBarcodePrefix + Guid.NewGuid().ToString().Replace("-", string.Empty);

            return result;
        }
    }
}
