﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class BatchController : ControllerBase
    {

        #region [ Cosntructor(s) ]

        public BatchController(IBatchService batchService)
        {
            _batchService = batchService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getbybatchId/{languageId}")]
        public IActionResult GetByBatchId([FromBody] int batchId, [FromRoute] int languageId)
        {
            if (batchId <= 0)
                return BadRequest("Invalid batch Id");

            List<BatchApiModel> resultBucketApiList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            Batch batch = _batchService.LoadByBatchId(batchId);

            BatchApiModel tempBatchApi = null;

            if (batch != null)
            {
                tempBatchApi = MapDBModelToApiModel(batch);
            }

            return Ok(tempBatchApi);
        }

        [HttpGet]
        [Route("getactivebatches/{languageId}")]
        public IActionResult GetActiveBatch([FromRoute] int languageId)
        {
            List<BatchApiModel> resultBatchApiList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Batch> batchList = _batchService.LoadAll();

            if (batchList != null)
            {
                resultBatchApiList = new List<BatchApiModel>();
                BatchApiModel tempBatchApi = null;

                foreach (var item in batchList)
                {
                    tempBatchApi = MapDBModelToApiModel(item);
                    resultBatchApiList.Add(tempBatchApi);
                }
            }

            return Ok(resultBatchApiList);
        }

        [HttpGet]
        [Route("getactivebatchesbystaffid/{languageId}")]
        public IActionResult GetActiveBatchByStaffId([FromBody] int staffId, [FromRoute] int languageId)
        {
            if (staffId <= 0)
                return BadRequest("Invalid staff Id");

            List<BatchApiModel> resultBatchApiList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Batch> batchList = _batchService.LoadActiveByStaffId(staffId);

            if (batchList != null)
            {
                resultBatchApiList = new List<BatchApiModel>();
                BatchApiModel tempBatchApi = null;

                foreach (var item in batchList)
                {
                    tempBatchApi = MapDBModelToApiModel(item);
                    resultBatchApiList.Add(tempBatchApi);
                }
            }

            return Ok(resultBatchApiList);
        }

        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddBatch([FromBody] BatchApiModel batchApiModel, [FromRoute] int languageId)
        {
            if (batchApiModel == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Batch batch = MapApiModelToDBModel(batchApiModel);
                tempResult = _batchService.Add(batch);

                if (tempResult.IsSuccess)
                {
                    batchApiModel.BatchId = batch.BatchId;
                    tempResult.DataObject = batchApiModel;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditBatch([FromBody] BatchApiModel batchApiModel, [FromRoute] int languageId)
        {
            if (batchApiModel == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Batch batch = MapApiModelToDBModel(batchApiModel);
                tempResult = _batchService.Edit(batch);

                if (tempResult.IsSuccess)
                    tempResult.DataObject = batchApiModel;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("editstatus/{languageId}")]
        public IActionResult EditStatusBatch([FromBody] BatchApiModel batchApiModel, [FromRoute] int languageId)
        {
            if (batchApiModel == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _batchService.EditStatus(batchApiModel.BatchId, batchApiModel.BatchStatus);

                if (tempResult.IsSuccess)
                    tempResult.DataObject = batchApiModel;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int batchId, [FromRoute] int languageId)
        {
            if (batchId <= 0)
                return BadRequest("Invalid batch Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _batchService.DeleteByBatchId(batchId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IBatchService _batchService = null;

        #endregion

        #region [ Private Method(s) ]

        private Batch MapApiModelToDBModel(BatchApiModel batchApiModel)
        {
            Batch result = new Batch();

            result.BatchBarcode = batchApiModel.BatchBarcode;
            result.BatchId = batchApiModel.BatchId;
            result.CreateDate = batchApiModel.CreateDate;
            result.StaffId = batchApiModel.StaffId;
            result.StatusId = batchApiModel.StatusId;
            result.WorkProcessStepId = batchApiModel.WorkProcessStepId;

            BatchItem tempItem = null;
            List<BatchItem> tempItems = new List<BatchItem>();

            foreach (var item in batchApiModel.BatchItemApiModelList)
            {
                tempItem = new BatchItem();
                tempItem.BatchId = item.BatchId;
                tempItem.BatchItemId = item.BatchItemId;
                tempItem.BucketId = item.BucketId;
                tempItem.UsedAmount = item.UsedAmount;

                tempItems.Add(tempItem);
            }

            result.BatchItems = tempItems;

            return result;
        }

        private BatchApiModel MapDBModelToApiModel(Batch batch)
        {
            BatchApiModel temp = new BatchApiModel();

            temp.BatchId = batch.BatchId;
            temp.CreateDate = batch.CreateDate;
            temp.StaffId = batch.StaffId;
            temp.StaffName = $"{batch.Staff.FirstName} {batch.Staff.LastName}";
            temp.StatusId = batch.StatusId;
            temp.BatchBarcode = batch.BatchBarcode;
            temp.WorkProcessStepId = batch.WorkProcessStepId;
            temp.WorkProcessStepAmount = batch.WorkProcessStep.Amount;
            temp.WorkProcessId = batch.WorkProcessStep.WorkProcessId;

            if (batch.BatchItems != null)
            {
                temp.BatchItemApiModelList = new List<BatchItemApiModel>();
                BatchItemApiModel tempItem = null;
                foreach (var item in batch.BatchItems)
                {
                    tempItem = new BatchItemApiModel();
                    tempItem.BatchId = item.BatchId;
                    tempItem.BatchItemId = item.BatchItemId;
                    tempItem.BucketId = item.BucketId;
                    tempItem.BucketBarcode = item.Bucket.Barcode;
                    tempItem.BucketPaintName = item.Bucket.Paint.PaintName;
                    tempItem.UsedAmount = item.UsedAmount;

                    temp.BatchItemApiModelList.Add(tempItem);
                }
            }

            return temp;
        }

        #endregion
    }
}
