﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class WorkProcessController : ControllerBase
    {

        #region [ Constructor(s) ]

        public WorkProcessController(IWorkProcessService workProcessService)
        {
            _workProcessService = workProcessService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getactiveworkprocess/{languageId}")]
        public IActionResult GetActiveWorkProcess([FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<WorkProcess> workProcessList = _workProcessService.LoadAllActive();

            List<WorkProcessApiModel> workProcessApiList = new List<WorkProcessApiModel>();
            WorkProcessApiModel temp = null;

            foreach (var item in workProcessList)
            {
                temp = MapWorkProcesseModelToApiModel(item);
                workProcessApiList.Add(temp);
            }

            return Ok(workProcessApiList);
        }

        [HttpGet]
        [Route("getbyworkprocessid/{languageId}")]
        public IActionResult GetByWorkProcessId([FromBody] int workProcessId, [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            WorkProcess workProcess = _workProcessService.LoadById(workProcessId);
            if (workProcess == null)
                return NotFound();

            WorkProcessApiModel temp = null;
            temp = MapWorkProcesseModelToApiModel(workProcess);

            return Ok(temp);
        }

        [HttpGet]
        [Route("getbyworkprocessstepid/{languageId}")]
        public IActionResult GetByWorkProcessStepId([FromBody] int workProcessStepId, [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            WorkProcess workProcess = _workProcessService.LoadByWorkProcessStepId(workProcessStepId);
            if (workProcess == null)
                return NotFound();

            WorkProcessApiModel temp = null;
            temp = MapWorkProcesseModelToApiModel(workProcess);

            return Ok(temp);
        }


        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddWorkProcess([FromBody] WorkProcessApiModel workProcessApi, [FromRoute] int languageId)
        {
            if (workProcessApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                WorkProcess workProcess = MapApiModelToWorkProcessModel(workProcessApi);
                tempResult = _workProcessService.Add(workProcess);
                if (tempResult.IsSuccess)
                {
                    workProcessApi.WorkProcessId = workProcess.WorkProcessId;
                    tempResult.DataObject = workProcessApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditWorkProcess([FromBody] WorkProcessApiModel workProcessApi, [FromRoute] int languageId)
        {
            if (workProcessApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                var deletedItemList = workProcessApi.WorkProcessSteps.Where(w => w.IsDeleted).ToList();
                if (deletedItemList != null && deletedItemList.Count > 0)
                    tempResult = _workProcessService.DeleteWorkProcessStepByWorkProcessStepIds(deletedItemList.Select(s => s.WorkProcessStepId).ToList());

                if (tempResult == null || tempResult.IsSuccess)
                {
                    WorkProcess workProcess = MapApiModelToWorkProcessModel(workProcessApi);
                    tempResult = _workProcessService.Edit(workProcess);

                    if (tempResult.IsSuccess)
                    {
                        workProcessApi.WorkProcessId = workProcess.WorkProcessId;
                        tempResult.DataObject = workProcessApi;
                    }
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("editstatus/{languageId}")]
        public IActionResult EditStatusWorkProcess([FromBody] WorkProcessApiModel workProcessApi, [FromRoute] int languageId)
        {
            if (workProcessApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _workProcessService.EditStatus(workProcessApi.WorkProcessId, workProcessApi.WorkProcessStatus);

                if (tempResult.IsSuccess)
                {
                    tempResult.DataObject = workProcessApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int workProcessId, [FromRoute] int languageId)
        {
            if (workProcessId <= 0)
                return BadRequest("Invalid workProcess Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _workProcessService.DeleteByWorkProcessId(workProcessId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IWorkProcessService _workProcessService = null;

        #endregion

        #region [ Private Method(s) ]

        private WorkProcessApiModel MapWorkProcesseModelToApiModel(WorkProcess item)
        {
            WorkProcessApiModel result = new WorkProcessApiModel();

            result.Amount = item.Amount;
            result.OrderItemAmount = item.OrderItem.Amount;
            result.AssignedStaffId = item.StaffId;
            result.CreateDate = item.CreateDate;
            result.IsDeleted = item.IsDeleted;
            result.OrderItemId = item.OrderItemId;
            result.OrderCode = item.OrderItem.Order.OrderCode;
            result.WorkPieceName = item.OrderItem.WorkPiece.WorkPieceName;
            result.StaffName = item.Staff.FirstName + " " + item.Staff.LastName;
            result.StatusId = item.StatusId;
            result.WorkProcessId = item.WorkProcessId;
            result.WorkProcessStartDate = item.WorkProcessStartDate;

            if (item.WorkProcessSteps != null)
            {
                List<WorkProcessStepApiModel> tempStepList = new List<WorkProcessStepApiModel>();
                WorkProcessStepApiModel tempStep = null;
                foreach (var step in item.WorkProcessSteps)
                {
                    tempStep = new WorkProcessStepApiModel();
                    tempStep.Amount = step.Amount;
                    tempStep.PaintId = step.PaintId;
                    tempStep.PaintName = step.Paint.PaintName;
                    tempStep.PaintTypeId = step.Paint.PaintTypeId;
                    tempStep.StatusId = step.StatusId;
                    tempStep.StepIndex = step.StepIndex;
                    tempStep.WorkProcessId = step.WorkProcessId;

                    if (tempStep.WorkProcessStepId < 0)
                        tempStep.WorkProcessStepId = 0;
                    else
                        tempStep.WorkProcessStepId = step.WorkProcessStepId;

                    tempStepList.Add(tempStep);
                }

                result.WorkProcessSteps = tempStepList;
            }

            return result;
        }

        private WorkProcess MapApiModelToWorkProcessModel(WorkProcessApiModel workProcessApi)
        {
            WorkProcess result = null;

            if (workProcessApi != null)
            {
                result = new WorkProcess();
                result.Amount = workProcessApi.Amount;
                result.StaffId = workProcessApi.AssignedStaffId;
                result.CreateDate = workProcessApi.CreateDate;
                result.IsDeleted = workProcessApi.IsDeleted;
                result.OrderItemId = workProcessApi.OrderItemId;
                result.StatusId = workProcessApi.StatusId;
                result.WorkProcessId = workProcessApi.WorkProcessId;
                result.WorkProcessStartDate = workProcessApi.WorkProcessStartDate;

                if (workProcessApi.WorkProcessSteps != null)
                {
                    List<WorkProcessStep> tempSteps = new List<WorkProcessStep>();
                    WorkProcessStep temp = null;

                    foreach (var item in workProcessApi.WorkProcessSteps.Where(w => !w.IsDeleted))
                    {
                        temp = new WorkProcessStep();
                        temp.Amount = item.Amount;
                        temp.PaintId = item.PaintId;
                        temp.StatusId = item.StatusId;
                        temp.StepIndex = item.StepIndex;
                        temp.WorkProcessId = item.WorkProcessId;

                        if (item.WorkProcessStepId < 0)
                            temp.WorkProcessStepId = 0;
                        else
                            temp.WorkProcessStepId = item.WorkProcessStepId;

                        tempSteps.Add(temp);
                    }

                    result.WorkProcessSteps = tempSteps;
                }
            }

            return result;
        }

        #endregion

    }
}
