﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {

        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        // GET: api/<SupplierController>
        [HttpGet]
        [Route("getbycustomerId/{languageId}")]
        public IActionResult GetByCustomerId(int customerId, [FromRoute] int languageId)
        {
            if (customerId <= 0)
                return BadRequest("Invalid customer Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            CustomerApiModel customerApi = null;
            try
            {
                Customer customer = _customerService.LoadByCustomerId(customerId);
                if (customer == null)
                    BadRequest("There is no customer ");

                customerApi = MapCustomerModelToApiModel(customer);
            }
            catch (Exception exp)
            {
                BadRequest("There is no customer ");
            }

            return Ok(customerApi);

        }

        // GET api/<SupplierController>/5
        [HttpGet]
        [Route("getactivecustomers/{languageId}")]
        public IActionResult GetAcitveCustomers( [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Customer> customerList = _customerService.LoadActiveCustomers();

            List<CustomerApiModel> customerApiModelList = new List<CustomerApiModel>();
            CustomerApiModel temp = null;

            foreach (var item in customerList)
            {
                temp = MapCustomerModelToApiModel(item);
                customerApiModelList.Add(temp);
            }

            return Ok(customerApiModelList);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddCustomer([FromBody] CustomerApiModel customerApi, [FromRoute] int languageId)
        {
            if (customerApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Customer customer = MapApiModelToCustomerModel(customerApi);
                tempResult = _customerService.Add(customer);
                if (tempResult.IsSuccess)
                {
                    customerApi.CustomerId = customer.CustomerId;
                    tempResult.DataObject = customerApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditCustomer([FromBody] CustomerApiModel customerApi, [FromRoute] int languageId)
        {
            if (customerApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Customer customer = MapApiModelToCustomerModel(customerApi);
                tempResult = _customerService.Edit(customer);
                if (tempResult.IsSuccess)
                    tempResult.DataObject = customerApi;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // DELETE api/<SupplierController>/5
        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int customerId, [FromRoute] int languageId)
        {
            if (customerId <= 0)
                return BadRequest("Invalid Supplier Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _customerService.DeleteByCustomerId(customerId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #region [ Private Field(s) ]

        private readonly ICustomerService _customerService = null;

        #endregion

        #region [ Private Method(s) ]

        private CustomerApiModel MapCustomerModelToApiModel(Customer customer)
        {

            CustomerApiModel tempCustomer = new CustomerApiModel()
            {
                CustomerId = customer.CustomerId,
                CustomerName = customer.CustomerName,
                Email = customer.Email,
                Address = customer.Address,
                PhoneNumber = customer.PhoneNumber,
                IsDeleted = customer.IsDeleted
            };

            return tempCustomer;
        }

        private Customer MapApiModelToCustomerModel(CustomerApiModel customerApi)
        {

            Customer tempCustomer = new Customer()
            {
                CustomerId = customerApi.CustomerId,
                CustomerName = customerApi.CustomerName,
                Email = customerApi.Email,
                Address = customerApi.Address,
                PhoneNumber = customerApi.PhoneNumber,
                IsDeleted = customerApi.IsDeleted
            };

            return tempCustomer;
        }

        #endregion
    }
}
