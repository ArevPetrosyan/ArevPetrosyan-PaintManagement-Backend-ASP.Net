﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaintManagement.API.Controllers
{

    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Produces("application/json")]
    [ApiController]
    public class StaffController : ControllerBase
    {

        #region [ Constructor(s) ]

        public StaffController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getactivestaff/{languageId}")]
        public IActionResult GetActiveStaff([FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Staff> staffList = _staffService.LoadActiveStaff();

            List<StaffApiModel> tempList = new List<StaffApiModel>();
            foreach (var item in staffList)
            {
                var temp = MapDbModelTopApiModel(item);
                tempList.Add(temp);
            }

            return Ok(tempList);
        }

        [HttpGet]
        [Route("getbystaffid/{languageId}")]
        public IActionResult GetByStaffId([FromBody] int staffId, [FromRoute] int languageId)
        {
            if (staffId <= 0)
                return BadRequest("Invalid staff Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            Staff staff = _staffService.LoadById(staffId);
            if (staff == null)
                return NotFound();

            StaffApiModel temp = MapDbModelTopApiModel(staff);
            return Ok(temp);
        }

        [HttpGet]
        [Route("getbyauthenticationbarcode/{languageId}")]
        public IActionResult GetByAuthenticationBarcode([FromBody] string authenticationBarcode, [FromRoute] int languageId)
        {
            if (string.IsNullOrEmpty(authenticationBarcode))
                return BadRequest("Invalid Authentication Barcode");

            MessageHandler.SetMessageCulture((Language)languageId);

            StaffApiModel temp = null;

            Staff staff = _staffService.LoadByAuthenticationBarcode(authenticationBarcode);
            if (staff == null)
                return NotFound();

            temp = MapDbModelTopApiModel(staff);

            return Ok(temp);
        }

        [HttpGet]
        [Route("getbyauthenticationtagid/{languageId}")]
        public IActionResult GetByAuthenticationTagId([FromBody] string authenticationTagId, [FromRoute] int languageId)
        {
            if (string.IsNullOrEmpty(authenticationTagId))
                return BadRequest("Invalid Authentication TagId");

            MessageHandler.SetMessageCulture((Language)languageId);

            StaffApiModel temp = null;

            Staff staff = _staffService.LoadByAuthenticationTagId(authenticationTagId);
            if (staff == null)
                return NotFound();

            temp = MapDbModelTopApiModel(staff);

            return Ok(temp);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddStaff([FromBody] StaffApiModel staffApi, [FromRoute] int languageId)
        {
            if (staffApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;
            try
            {
                var staff = MapApiModelTopDBModel(staffApi);
                tempResult = _staffService.Add(staff);
                if (tempResult.IsSuccess)
                {
                    staffApi.StaffId = staff.StaffId;
                    tempResult.DataObject = staffApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditStaff([FromBody] StaffApiModel staffApi, [FromRoute] int languageId)
        {
            if (staffApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;
            try
            {
                var staff = MapApiModelTopDBModel(staffApi);
                tempResult = _staffService.Edit(staff);
                if (tempResult.IsSuccess)
                    tempResult.DataObject = staff;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // DELETE api/<SupplierController>/5
        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int staffId, [FromRoute] int languageId)
        {
            if (staffId <= 0)
                return BadRequest("Invalid staff Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _staffService.DeleteByStaffId(staffId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IStaffService _staffService = null;

        #endregion

        #region [ Private Method(s) ]

        private StaffApiModel MapDbModelTopApiModel(Staff staff)
        {
            StaffApiModel result = new StaffApiModel()
            {
                AuthenticationBarcode = staff.AuthenticationBarcode,
                AuthenticationTagId = staff.AuthenticationTagId,
                CanLoginFromMobile = staff.CanLoginFromMobile,
                Email = staff.Email,
                FirstName = staff.FirstName,
                IsDeleted = staff.IsDeleted,
                LastActivity = staff.LastActivity,
                LastName = staff.LastName,
                Password = staff.Password,
                StaffId = staff.StaffId,
                Username = staff.Username
            };

            return result;
        }

        private Staff MapApiModelTopDBModel(StaffApiModel staffApi)
        {
            Staff result = new Staff()
            {
                AuthenticationBarcode = staffApi.AuthenticationBarcode,
                AuthenticationTagId = staffApi.AuthenticationTagId,
                CanLoginFromMobile = staffApi.CanLoginFromMobile,
                Email = staffApi.Email,
                FirstName = staffApi.FirstName,
                IsDeleted = staffApi.IsDeleted,
                LastActivity = staffApi.LastActivity,
                LastName = staffApi.LastName,
                Password = staffApi.Password,
                StaffId = staffApi.StaffId,
                Username = staffApi.Username
            };

            return result;
        }

        #endregion

    }
}
