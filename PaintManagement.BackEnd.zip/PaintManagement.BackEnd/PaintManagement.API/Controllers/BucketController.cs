﻿using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Models.DB.Views;
using PaintManagement.Common.Utilities.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class BucketController : Controller
    {
        #region [ Cosntructor(s) ]

        public BucketController(IBucketService bucketService)
        {
            _bucketService = bucketService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getbybucketId/{languageId}")]
        public IActionResult GetByBucketId([FromBody] int bucketId, [FromRoute] int languageId)
        {
            if (bucketId <= 0)
                return BadRequest("Invalid Bucket Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            BucketApiModel bucketApi = null;

            Bucket tempBucket = _bucketService.GetByBucketId(bucketId);

            if (tempBucket != null)
                bucketApi = MapBucketModelToApiMode(tempBucket);

            return Ok(bucketApi);
        }

        [HttpGet]
        [Route("getbybarcode/{languageId}")]
        public IActionResult GetByBarcode([FromBody] string barcode, [FromRoute] int languageId)
        {
            if (string.IsNullOrEmpty(barcode))
                return BadRequest("Invalid Bucket barcode");

            MessageHandler.SetMessageCulture((Language)languageId);

            BucketApiModel bucketApi = null;

            Bucket tempBucket = _bucketService.GetByBarcode(barcode);

            if (tempBucket != null)
                bucketApi = MapBucketModelToApiMode(tempBucket);

            return Ok(bucketApi);
        }

        [HttpGet]
        [Route("getbybatchid/{languageId}")]
        public IActionResult GetByBatchId([FromBody] int batchId, [FromRoute] int languageId)
        {
            if (batchId <= 0)
                return BadRequest("Invalid batch Id");

            List<BucketApiModel> resultBucketApiList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Bucket> bucketList = _bucketService.LoadBucketByBatchId(batchId);

            if (bucketList != null)
            {
                resultBucketApiList = new List<BucketApiModel>();
                BucketApiModel tempBucketAPi = null;

                foreach (var item in bucketList)
                {
                    tempBucketAPi = MapBucketModelToApiMode(item);
                    resultBucketApiList.Add(tempBucketAPi);
                }
            }

            return Ok(resultBucketApiList);
        }

        [HttpGet]
        [Route("getactivebucketsbypaintId/{languageId}")]
        public IActionResult GetActiveBucketByPaintId([FromBody] int paintId, [FromRoute] int languageId)
        {
            if (paintId <= 0)
                return BadRequest("Invalid paint Id");

            List<BucketApiModel> resultBucketApiList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Bucket> bucketList = _bucketService.LoadAcitveBucketByPaintId(paintId);

            if (bucketList != null)
            {
                resultBucketApiList = new List<BucketApiModel>();
                BucketApiModel tempBucketAPi = null;

                foreach (var item in bucketList)
                {
                    tempBucketAPi = MapBucketModelToApiMode(item);
                    resultBucketApiList.Add(tempBucketAPi);
                }
            }

            return Ok(resultBucketApiList);
        }

        [HttpGet]
        [Route("getactivebucketexpirealarm/{languageId}")]
        public IActionResult GetActiveBucketExpireAlarm([FromBody] int remainDays, [FromRoute] int languageId)
        {
            List<BucketApiReportModel> reportDataList = null;
            MessageHandler.SetMessageCulture((Language)languageId);

            List<BucketView> tempList = _bucketService.LoadActiveBucketByBestBeforeRemainDays(remainDays);

            if (tempList != null)
                reportDataList = MapBucketViewToApiReportModel(tempList);

            return Ok(reportDataList);
        }

        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddBucket([FromBody] BucketApiModel bucketApi, [FromRoute] int languageId)
        {
            if (bucketApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Bucket bucket = MapApiModelToBucketModel(bucketApi);
                tempResult = _bucketService.Add(bucket, bucketApi.BucketCount);

                if (tempResult.IsSuccess)
                {
                    List<Bucket> tempBuckets = (List<Bucket>)tempResult.DataObject;
                    List<BucketApiModel> bucketApiList = tempBuckets.Select(s => MapBucketModelToApiMode(s)).ToList();

                    tempResult.DataObject = bucketApiList;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditBucket([FromBody] BucketApiModel bucketApi, [FromRoute] int languageId)
        {
            if (bucketApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Bucket bucket = MapApiModelToBucketModel(bucketApi);
                tempResult = _bucketService.Edit(bucket);

                if (tempResult.IsSuccess)
                    tempResult.DataObject = bucketApi;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int bucketId, [FromRoute] int languageId)
        {
            if (bucketId <= 0)
                return BadRequest("Invalid bucket Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _bucketService.DeleteByBucketId(bucketId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IBucketService _bucketService = null;

        #endregion

        #region [ Private Method(s) ]

        private Bucket MapApiModelToBucketModel(BucketApiModel bucketApi)
        {
            Bucket tempBucket = new Bucket()
            {
                BucketId = bucketApi.BucketId,
                PaintId = bucketApi.PaintId,
                Amount = bucketApi.Amount,
                Barcode = bucketApi.Barcode,
                BestBefore = bucketApi.BestBefore,
                ManufacturerBatchNumber = bucketApi.ManufacturerBatchNumber,
                ProductionDate = bucketApi.ProductionDate,
                RemainingAmount = bucketApi.RemainingAmount,
                IsEmpty = bucketApi.IsEmpty,
                IsDeleted = bucketApi.IsDeleted
            };

            return tempBucket;
        }

        private BucketApiModel MapBucketModelToApiMode(Bucket bucket)
        {
            BucketApiModel tempBucketApi = new BucketApiModel()
            {
                BucketId = bucket.BucketId,
                PaintId = bucket.PaintId,
                Amount = bucket.Amount,
                Barcode = bucket.Barcode,
                BestBefore = bucket.BestBefore,
                ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                ProductionDate = bucket.ProductionDate,
                RemainingAmount = bucket.RemainingAmount,
                IsEmpty = bucket.IsEmpty,
                IsDeleted = bucket.IsDeleted
            };

            if (bucket.Paint != null)
                tempBucketApi.PaintName = bucket.Paint.PaintName;

            return tempBucketApi;
        }

        private List<BucketApiReportModel> MapBucketViewToApiReportModel(List<BucketView> bucketViewList)
        {
            List<BucketApiReportModel> tempResultList = new List<BucketApiReportModel>();

            BucketApiReportModel temp = null;
            foreach (var item in bucketViewList)
            {
                temp = new BucketApiReportModel(item);
                tempResultList.Add(temp);
            }

            return tempResultList;
        }

        #endregion
    }
}
