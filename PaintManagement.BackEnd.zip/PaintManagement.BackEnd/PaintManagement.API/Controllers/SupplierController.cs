﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        #region [ Constructor(s) ]

        public SupplierController(ISupplierService supplierService)
        {
            _supplierService = supplierService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getactivesuppliers/{languageId}")]
        public IActionResult GetActiveSupplier([FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Supplier> supllierList = _supplierService.LoadActiveSuppliers();

            List<SupplierApiModel> supplierApiModelList = new List<SupplierApiModel>();
            SupplierApiModel temp = null;

            foreach (var item in supllierList)
            {
                temp = MapSupplierModelToApiModel(item);
                supplierApiModelList.Add(temp);
            }

            return Ok(supplierApiModelList);
        }

        //GET api/<SupplierController>/5
        [HttpGet]
        [Route("getBysupplierid/{languageId}")]
        public IActionResult GetBySupplierId([FromBody] int supplierId, [FromRoute] int languageId)
        {
            if (supplierId <= 0)
                return BadRequest("Invalid Supplier Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            //Common.Messages.MessageHandler.SetMessageCulture((Common.Utilities.Enumerations.Language)languageId);
            //var tempMsg = Common.Messages.MessageResource.SupplierHasActivePaint;

            return Ok();
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddSupplier([FromBody] SupplierApiModel supplierApi, [FromRoute] int languageId)
        {
            if (supplierApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;
            try
            {
                Supplier supplier = MapApiModelToSupplierModel(supplierApi);
                tempResult = _supplierService.Add(supplier);
                if (tempResult.IsSuccess)
                {
                    supplierApi.SupplierId = supplier.SupplierId;
                    tempResult.DataObject = supplierApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditSupplier([FromBody] SupplierApiModel supplierApi, [FromRoute] int languageId)
        {
            if (supplierApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;
            try
            {
                Supplier supplier = MapApiModelToSupplierModel(supplierApi);
                tempResult = _supplierService.Edit(supplier);
                if (tempResult.IsSuccess)
                    tempResult.DataObject = supplierApi;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // DELETE api/<SupplierController>/5
        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int supplierId, [FromRoute] int languageId)
        {
            if (supplierId <= 0)
                return BadRequest("Invalid Supplier Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _supplierService.DeleteBySupplierId(supplierId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly ISupplierService _supplierService = null;

        #endregion

        #region [ Private Method(s) ]

        private SupplierApiModel MapSupplierModelToApiModel(Supplier supplier)
        {
            SupplierApiModel tempSupplierApiModel = new SupplierApiModel()
            {
                SupplierId = supplier.SupplierId,
                SupplierName = supplier.SupplierName,
                PhoneNumber = supplier.PhoneNumber,
                Address = supplier.Address,
                Email = supplier.Email,
                IsDeleted = supplier.IsDeleted
            };

            return tempSupplierApiModel;
        }

        private Supplier MapApiModelToSupplierModel(SupplierApiModel supplierApi)
        {
            Supplier tempSupplier = new Supplier()
            {
                SupplierId = supplierApi.SupplierId,
                SupplierName = supplierApi.SupplierName,
                Address = supplierApi.Address,
                Email = supplierApi.Email,
                PhoneNumber = supplierApi.PhoneNumber,
                IsDeleted = supplierApi.IsDeleted
            };

            return tempSupplier;
        }

        #endregion

    }
}
