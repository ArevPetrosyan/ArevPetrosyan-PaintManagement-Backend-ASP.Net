﻿using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Models.API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.Common;

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class OrderController : Controller
    {
        #region [ Constructor(s) ]

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getactiveorders/{languageId}")]
        public IActionResult GetActiveOrder([FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Order> tempOrderList = _orderService.LoadActiveOrders();

            OrderApiModel tempOrderApiModel = null;

            List<OrderApiModel> tempOrderApiModelList = new List<OrderApiModel>();
            foreach (var item in tempOrderList)
            {
                tempOrderApiModel = MapOrderModelToApiModel(item);

                tempOrderApiModelList.Add(tempOrderApiModel);
            }

            return Ok(tempOrderApiModelList);
        }

        [HttpGet]
        [Route("getorderbyid/{languageId}")]
        public IActionResult GetByOrderId([FromBody] int orderId, [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            Order tempOrder = _orderService.LoadOrderById(orderId);

            if (tempOrder == null)
                return NotFound();

            OrderApiModel tempOrderApiModel = null;
            tempOrderApiModel = MapOrderModelToApiModel(tempOrder);

            return Ok(tempOrderApiModel);
        }

        [HttpGet]
        [Route("getactiveorderbycustomerid/{languageId}")]
        public IActionResult GetActiveOrderByCustomerId([FromBody] int customerId, [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Order> tempOrderList = _orderService.LoadActiveOrderByCustomerId(customerId);

            OrderApiModel tempOrderApiModel = null;
            if (tempOrderList == null)
                return NotFound();

            List<OrderApiModel> tempOrderApiModelList = new List<OrderApiModel>();
            foreach (var item in tempOrderList)
            {
                tempOrderApiModel = MapOrderModelToApiModel(item);

                tempOrderApiModelList.Add(tempOrderApiModel);
            }

            return Ok(tempOrderApiModelList);
        }

        [HttpGet]
        [Route("getactiveorderbyorderstatusid/{languageId}")]
        public IActionResult GetActiveOrderByOrderStatusId([FromBody] int orderStatusId, [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<Order> tempOrderList = _orderService.LoadActiveOrderByOrderStatusId(orderStatusId);

            OrderApiModel tempOrderApiModel = null;

            List<OrderApiModel> tempOrderApiModelList = new List<OrderApiModel>();
            foreach (var item in tempOrderList)
            {
                tempOrderApiModel = MapOrderModelToApiModel(item);

                tempOrderApiModelList.Add(tempOrderApiModel);
            }

            return Ok(tempOrderApiModelList);
        }

        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddOrder([FromBody] OrderApiModel orderApiModel, [FromRoute] int languageId)
        {
            if (orderApiModel == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                Order order = MapApiModelToOrderModel(orderApiModel);
                tempResult = _orderService.Add(order);
                if (tempResult.IsSuccess)
                {
                    orderApiModel.OrderId = order.OrderId;
                    tempResult.DataObject = orderApiModel;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditOrder([FromBody] OrderApiModel orderApiModel, [FromRoute] int languageId)
        {
            if (orderApiModel == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                var tempDeletedItems = orderApiModel.OrderItemApiModelList.Where(w => w.IsDeleted).ToList();
                if (tempDeletedItems != null && tempDeletedItems.Count > 0)
                    tempResult = _orderService.DeleteOrderItemByOrderItemIds(tempDeletedItems.Select(s => s.OrderItemId).ToList());

                if (tempResult == null || tempResult.IsSuccess)
                {
                    Order order = MapApiModelToOrderModel(orderApiModel);
                    tempResult = _orderService.Edit(order);

                    if (tempResult.IsSuccess)
                    {
                        orderApiModel.OrderId = order.OrderId;
                        tempResult.DataObject = orderApiModel;
                    }
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int orderId, [FromRoute] int languageId)
        {
            if (orderId <= 0)
                return BadRequest("Invalid order Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _orderService.DeleteByOrderId(orderId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IOrderService _orderService = null;

        #endregion

        #region [ Private Method(s) ]

        private OrderApiModel MapOrderModelToApiModel(Order tempOrder)
        {
            OrderApiModel temp = new OrderApiModel()
            {
                CreateData = tempOrder.CreateDate,
                CustomerId = tempOrder.CustomerId,
                CustomerName = tempOrder.Customer.CustomerName,
                DeliveryDate = tempOrder.DeliveryDate,
                IsDeleted = tempOrder.IsDeleted,
                OrderCode = tempOrder.OrderCode,
                OrderId = tempOrder.OrderId,
                OrderStatusId = tempOrder.OrderStatusId
            };

            if (tempOrder.OrderItems != null)
            {
                OrderItemApiModel tempItemApiModel = null;
                temp.OrderItemApiModelList = new List<OrderItemApiModel>();

                foreach (var item in tempOrder.OrderItems)
                {
                    tempItemApiModel = new OrderItemApiModel()
                    {
                        Amount = item.Amount,
                        OrderId = item.OrderId,
                        OrderItemId = item.OrderItemId,
                        PaintId = item.PaintId,
                        PaintName = item.Paint.PaintName,
                        PaintTypeId = item.Paint.PaintTypeId,
                        WorkPieceId = item.WorkPieceId,
                        WorkPieceName = item.WorkPiece.WorkPieceName
                    };

                    temp.OrderItemApiModelList.Add(tempItemApiModel);
                }
            }


            return temp;
        }

        private Order MapApiModelToOrderModel(OrderApiModel orderApiModel)
        {
            Order tempOrder = new Order()
            {
                CreateDate = orderApiModel.CreateData,
                CustomerId = orderApiModel.CustomerId,
                DeliveryDate = orderApiModel.DeliveryDate,
                IsDeleted = orderApiModel.IsDeleted,
                OrderCode = orderApiModel.OrderCode,
                OrderId = orderApiModel.OrderId,
                OrderStatusId = orderApiModel.OrderStatusId
            };


            if (orderApiModel.OrderItemApiModelList != null)
            {
                OrderItem tempOrderItem = null;
                List<OrderItem> tempOrderItemList = new List<OrderItem>();
                foreach (var item in orderApiModel.OrderItemApiModelList.Where(w => !w.IsDeleted))
                {
                    tempOrderItem = new OrderItem()
                    {
                        Amount = item.Amount,
                        OrderId = item.OrderId,
                        OrderItemId = item.OrderItemId,
                        PaintId = item.PaintId,
                        WorkPieceId = item.WorkPieceId
                    };
                    if (tempOrderItem.OrderItemId < 0)
                        tempOrderItem.OrderItemId = 0;

                    tempOrderItemList.Add(tempOrderItem);
                }

                tempOrder.OrderItems = tempOrderItemList;
            }

            return tempOrder;
        }

        #endregion
    }
}
