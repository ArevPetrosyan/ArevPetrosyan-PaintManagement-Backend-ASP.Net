﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.Common;

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class WorkPieceController : Controller
    {

        #region [ Constructor(s) ]

        public WorkPieceController(IWorkPieceService workPieceService)
        {
            _workPieceService = workPieceService;

        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getactiveworkpieces/{languageId}")]
        public IActionResult GetActiveWorkPiece( [FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<WorkPiece> workPieceList = _workPieceService.LoadActiveWorkPieces();

            List<WorkPieceApiModel> workPieceApiModelList = new List<WorkPieceApiModel>();
            WorkPieceApiModel temp = null;

            foreach (var item in workPieceList)
            {
                temp = MapWorkPieceModelToApiModel(item);
                workPieceApiModelList.Add(temp);
            }

            return Ok(workPieceApiModelList);
        }

        [HttpGet]
        [Route("getacticeworkpiecebycustomerid/{languageId}")]
        public IActionResult GetActiveWorkPieceByCustomerId([FromBody] int customerId, [FromRoute] int languageId)
        {
            if (customerId <= 0)
                return BadRequest("Invalid Customer Id");
            
            MessageHandler.SetMessageCulture((Language)languageId);

            List<WorkPieceApiModel> resultWorkPieceApiList = null;

            List<WorkPiece> workPieceList = _workPieceService.LoadActiveWorkPieceByCustomerId(customerId);

            if (workPieceList != null)
            {
                resultWorkPieceApiList = new List<WorkPieceApiModel>();
                WorkPieceApiModel tempWorkPieceAPi = null;

                foreach (var item in workPieceList)
                {
                    tempWorkPieceAPi = MapWorkPieceModelToApiModel(item);
                    resultWorkPieceApiList.Add(tempWorkPieceAPi);
                }
            }

            return Ok(resultWorkPieceApiList);
        }

        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddWorkPiece([FromBody] WorkPieceApiModel workPieceApi, [FromRoute] int languageId)
        {
            if (workPieceApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                WorkPiece workpiece = MapApiModelToWorkPieceModel(workPieceApi);
                tempResult = _workPieceService.Add(workpiece);
                if (tempResult.IsSuccess)
                {
                    workPieceApi.WorkPieceId = workpiece.WorkPieceId;
                    tempResult.DataObject = workPieceApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditWorkPiece([FromBody] WorkPieceApiModel workPieceApi, [FromRoute] int languageId)
        {
            if (workPieceApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                WorkPiece workpiece = MapApiModelToWorkPieceModel(workPieceApi);
                tempResult = _workPieceService.Edit(workpiece);
                if (tempResult.IsSuccess)
                {
                    workPieceApi.WorkPieceId = workpiece.WorkPieceId;
                    tempResult.DataObject = workPieceApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int workPieceId, [FromRoute] int languageId)
        {
            if (workPieceId <= 0)
                return BadRequest("Invalid workPiece Id");

            MessageHandler.SetMessageCulture((Language)languageId);
            ApiResult tempResult = null;

            try
            {
                tempResult = _workPieceService.DeleteByWorkPieceId(workPieceId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IWorkPieceService _workPieceService = null;

        #endregion

        #region [ Private Method(s) ]

        private WorkPieceApiModel MapWorkPieceModelToApiModel(WorkPiece workPiece)
        {
            WorkPieceApiModel temp = new WorkPieceApiModel()
            {
                CustomerId = workPiece.CustomerId,
                CustomerName = workPiece.Customer.CustomerName,
                IsDeleted = workPiece.IsDeleted,
                WorkPieceDescription = workPiece.WorkPieceDescription,
                WorkPieceId = workPiece.WorkPieceId,
                WorkPieceName = workPiece.WorkPieceName
            };
            return temp;
        }

        private WorkPiece MapApiModelToWorkPieceModel(WorkPieceApiModel workPieceApi)
        {
            WorkPiece temp = new WorkPiece()
            {
                CustomerId = workPieceApi.CustomerId,
                IsDeleted = workPieceApi.IsDeleted,
                WorkPieceDescription = workPieceApi.WorkPieceDescription,
                WorkPieceId = workPieceApi.WorkPieceId,
                WorkPieceName = workPieceApi.WorkPieceName
            };

            return temp;
        }

        #endregion
    }
}
