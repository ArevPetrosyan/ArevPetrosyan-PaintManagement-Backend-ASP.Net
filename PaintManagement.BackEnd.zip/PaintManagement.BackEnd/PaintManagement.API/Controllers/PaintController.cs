﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.API;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PaintManagement.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/{v:apiVersion}/[controller]")]
    //[Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class PaintController : ControllerBase
    {
        #region [ Constructor(s) ]

        public PaintController(IPaintService paintService, ISupplierService supplierService)
        {
            _paintService = paintService;
            _supplierService = supplierService;
        }

        #endregion

        #region [ Public Method(s) ]

        [HttpGet]
        [Route("getbypaintId/{languageId}")]
        public IActionResult GetByPaintId([FromBody] int paintId, [FromRoute] int languageId)
        {
            if (paintId <= 0)
                return BadRequest("Invalid Paint Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            PaintApiModel paintApi = null;
            Paint tempPaint = _paintService.LoadByPaintId(paintId);

            if (tempPaint != null)
                paintApi = MapPaintModelToApiMode(tempPaint);

            return Ok(paintApi);
        }

        [HttpGet]
        [Route("getconnectedpaintbypaintId/{languageId}")]
        public IActionResult GetConnectedPaintByPaintId([FromBody] int paintId, [FromRoute] int languageId)
        {
            if (paintId <= 0)
                return BadRequest("Invalid PaintId");

            MessageHandler.SetMessageCulture((Language)languageId);

            var tempPaintList = _paintService.LoadConnectedPaintByPaintId(paintId);

            List<PaintApiModel> resultPaintApiList = null;
            if (tempPaintList != null)
            {
                resultPaintApiList = new List<PaintApiModel>();
                PaintApiModel tempPaintAPi = null;

                foreach (var item in tempPaintList)
                {
                    tempPaintAPi = MapPaintModelToApiMode(item);
                    resultPaintApiList.Add(tempPaintAPi);
                }
            }

            return Ok(resultPaintApiList);
        }

        [HttpGet]
        [Route("getactivepaints/{languageId}")]
        public IActionResult GetActivePaint([FromRoute] int languageId)
        {
            MessageHandler.SetMessageCulture((Language)languageId);

            List<PaintApiModel> resultPaintApiList = null;

            List<Paint> paintList = _paintService.LoadActivePaint();

            if (paintList != null)
            {
                resultPaintApiList = new List<PaintApiModel>();
                PaintApiModel tempPaintAPi = null;

                foreach (var item in paintList)
                {
                    tempPaintAPi = MapPaintModelToApiMode(item);
                    resultPaintApiList.Add(tempPaintAPi);
                }
            }

            return Ok(resultPaintApiList);
        }

        [HttpGet]
        [Route("getactivepaintsbysupplierId/{languageId}")]
        public IActionResult GetActivePaintBySupplierId([FromBody] int supplierId, [FromRoute] int languageId)
        {
            if (supplierId <= 0)
                return BadRequest("Invalid supplier Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            List<PaintApiModel> resultPaintApiList = null;

            List<Paint> paintList = _paintService.LoadAcitvePaintBySupplierId(supplierId);

            if (paintList != null)
            {
                resultPaintApiList = new List<PaintApiModel>();
                PaintApiModel tempPaintAPi = null;

                foreach (var item in paintList)
                {
                    tempPaintAPi = MapPaintModelToApiMode(item);
                    resultPaintApiList.Add(tempPaintAPi);
                }
            }

            return Ok(resultPaintApiList);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("add/{languageId}")]
        public IActionResult AddPaint([FromBody] PaintApiModel paintApi, [FromRoute] int languageId)
        {
            if (paintApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;

            try
            {
                Paint paint = MapApiModelToPaintModel(paintApi);
                tempResult = _paintService.Add(paint);
                if (tempResult.IsSuccess)
                {
                    paintApi.PaintId = paint.PaintId;
                    tempResult.DataObject = paintApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        // POST api/<SupplierController>
        [HttpPost]
        [Route("edit/{languageId}")]
        public IActionResult EditPaint([FromBody] PaintApiModel paintApi, [FromRoute] int languageId)
        {
            if (paintApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;

            try
            {
                Paint paint = MapApiModelToPaintModel(paintApi);
                tempResult = _paintService.Edit(paint);
                if (tempResult.IsSuccess)
                    tempResult.DataObject = paintApi;
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpDelete]
        [Route("delete/{languageId}")]
        public IActionResult Delete([FromBody] int paintId, [FromRoute] int languageId)
        {
            if (paintId <= 0)
                return BadRequest("Invalid paint Id");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;

            try
            {
                tempResult = _paintService.DeleteByPaintId(paintId);
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("addconnectedpaint/{languageId}")]
        public IActionResult AddConnectedPaint([FromBody] PaintM2MApiModel paintM2MApi, [FromRoute] int languageId)
        {
            if (paintM2MApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;

            try
            {
                PaintM2M paintM2M = MapApiModelToPaintM2MModel(paintM2MApi);
                tempResult = _paintService.AddConnectedPaint(paintM2M);
                if (tempResult.IsSuccess)
                {
                    paintM2MApi.PaintM2MId = paintM2M.PaintM2MId;
                    tempResult.DataObject = paintM2MApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        [HttpPost]
        [Route("deleteconnectedpaint/{languageId}")]
        public IActionResult DeleteConnectedPaint([FromBody] PaintM2MApiModel paintM2MApi, [FromRoute] int languageId)
        {
            if (paintM2MApi == null)
                return BadRequest("Invalid parameter");

            MessageHandler.SetMessageCulture((Language)languageId);

            ApiResult tempResult = null;

            try
            {
                PaintM2M paintM2M = MapApiModelToPaintM2MModel(paintM2MApi);
                tempResult = _paintService.DeleteConnectedPaint(paintM2M);
                if (tempResult.IsSuccess)
                {
                    paintM2MApi.PaintM2MId = paintM2M.PaintM2MId;
                    tempResult.DataObject = paintM2MApi;
                }
            }
            catch (Exception exp)
            {
                //TODO: here we will add logging
                tempResult = new ApiResult();
                tempResult.IsSuccess = false;
                tempResult.Message = exp.ToString();
            }

            return Ok(tempResult);
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IPaintService _paintService = null;

        private readonly ISupplierService _supplierService = null;

        #endregion

        #region [ Private Method(s) ]

        private PaintApiModel MapPaintModelToApiMode(Paint paint)
        {
            PaintApiModel temp = new PaintApiModel()
            {
                PaintId = paint.PaintId,
                PaintName = paint.PaintName,
                PaintTypeId = paint.PaintTypeId,
                SolventContent = paint.SolventContent,
                SupplierId = paint.SupplierId,
                SupplierName = paint.Supplier.SupplierName,
                IsDeleted = paint.IsDeleted,
                OrderNumber = paint.OrderNumber,
                Color = paint.Color
            };

            return temp;
        }

        private Paint MapApiModelToPaintModel(PaintApiModel paintApi)
        {
            Paint temp = new Paint()
            {
                PaintId = paintApi.PaintId,
                PaintName = paintApi.PaintName,
                PaintTypeId = paintApi.PaintTypeId,
                SolventContent = paintApi.SolventContent,
                SupplierId = paintApi.SupplierId,
                IsDeleted = paintApi.IsDeleted,
                Color = paintApi.Color,
                OrderNumber = paintApi.OrderNumber
            };

            return temp;
        }

        private PaintM2M MapApiModelToPaintM2MModel(PaintM2MApiModel paintM2MApi)
        {
            PaintM2M result = new PaintM2M()
            {
                ConnectedPaintId = paintM2MApi.ConnectedPaintId,
                MainPaintId = paintM2MApi.MainPaintId,
                PaintM2MId = paintM2MApi.PaintM2MId
            };

            return result;
        }


        #endregion
    }
}
