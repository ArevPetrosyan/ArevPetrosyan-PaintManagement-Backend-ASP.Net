using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Service;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc.ApiExplorer;

namespace PaintManagement.API
{
    public class Startup
    {

        #region [ Constructor(s) ]

        public Startup(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
        {
            Configuration = configuration;
            this.hostEnvironment = hostEnvironment ?? throw new System.ArgumentNullException(nameof(hostEnvironment));

        }

        #endregion

        #region [ Public Property(s) ]

        public IConfiguration Configuration { get; }

        #endregion

        #region [ Poublic Method(s) ]

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            //services.AddMvc().AddNewtonsoftJson();
            //Manage versioning the api(s)
            services.AddApiVersioning(x =>
            {
                x.DefaultApiVersion = new ApiVersion(1, 0);
                x.AssumeDefaultVersionWhenUnspecified = true;
                x.ReportApiVersions = true;
            });

            services.AddVersionedApiExplorer(options =>
            {
                // add the versioned api explorer, which also adds IApiVersionDescriptionProvider service  
                // note: the specified format code will format the version as "'v'major[.minor][-status]"  
                options.GroupNameFormat = "'v'VVV";

                // note: this option is only necessary when versioning by url segment. the SubstitutionFormat  
                // can also be used to control the format of the API version in route templates  
                options.SubstituteApiVersionInUrl = true;
            });
            services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
            services.AddSwaggerGen(options => options.OperationFilter<SwaggerDefaultValues>());


            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("1.0", new OpenApiInfo { Title = hostEnvironment?.ApplicationName, Version = "1.0" });
            //});

            ConfigureSqlServerAccess(services);
            ConfigureDependencyInjection(services);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider provider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            //app.UseSwaggerUI(c =>
            //{
            //    c.SwaggerEndpoint("/swagger/1.0/swagger.json", "Paint Management API");
            //});

            app.UseSwaggerUI(
            options =>
            {
                // build a swagger endpoint for each discovered API version
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                }
            });
 

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        #endregion

        #region [ Private Field(s) ]

        private readonly IWebHostEnvironment? hostEnvironment;

        #endregion

        #region [ Private Method(s) ]

        private void ConfigureDependencyInjection(IServiceCollection services)
        {
            services.AddTransient<ISupplierService, SupplierService>();
            services.AddTransient<IPaintService, PaintService>();
            services.AddTransient<ICustomerService, CustomerService>();
            services.AddTransient<IBucketService, BucketService>();
            services.AddTransient<IWorkPieceService, WorkPieceService>();
            services.AddTransient<IOrderService, OrderService>();
            services.AddTransient<IStaffService, StaffService>();
            services.AddTransient<IBatchService, BatchService>();
            services.AddTransient<IWorkProcessService, WorkProcessService>();
        }

        private void ConfigureSqlServerAccess(IServiceCollection services)
        {
            //var connStr = new SqlDb.DbHelper().GetConnStr();

            string CnnStr = Configuration.GetSection("ConnectionString").Value;

            Common.GeneralParameter.ConnectionString = CnnStr;

            //services.AddDbContext<SqlDb.DbContextDefaultAndDeploy>(options =>
            //    options.UseSqlServer(CnnStr)
            //);
        }

        #endregion
    }
}
