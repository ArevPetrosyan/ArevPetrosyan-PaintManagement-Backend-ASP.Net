﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class BatchService : IBatchService
    {
        #region [ Constructor(s) ]

        public BatchService()
        {

        }

        #endregion

        #region [ Public Method(s) ]

        public List<Batch> LoadAll()
        {
            List<Batch> result = null;

            batchDa = new BatchDataAccess();
            result = batchDa.GetAllBatch();

            return result;
        }

        public Batch LoadByBatchId(int batchId)
        {
            Batch result = null;

            batchDa = new BatchDataAccess(null, false);
            result = batchDa.GetByBatchId(batchId);

            return result;
        }

        public List<Batch> LoadByStaffId(int staffId)
        {
            List<Batch> result = null;

            batchDa = new BatchDataAccess(null, false);
            result = batchDa.GetBatchByStaffId(staffId);

            return result;
        }

        public List<Batch> LoadActiveByStaffId(int staffId)
        {
            List<Batch> result = null;

            batchDa = new BatchDataAccess(null, false);
            result = batchDa.GetBatchByStaffId(staffId);

            //result = tempResult.Where(w => !w.IsDeleted).ToList();

            return result;
        }

        public ApiResult Add(Batch batch)
        {
            ApiResult result = null;
            batchDa = new BatchDataAccess(null, true);
            var tempContext = batchDa.MainDbContext;
            try
            {
                result = Validate(batch);

                if (result.IsSuccess)
                {

                    result.DataObject = batchDa.Insert(batch);

                    if (batch.StatusId == (int)BatchStatus.Confirm)
                    {
                        batch.BatchBarcode = CreateBatchBarcode(batch);
                        batchDa.Update(batch);
                    }

                    //After inserting the batch need to update bucket amount information 
                    BucketDataAccess bucketDa = new BucketDataAccess(tempContext, false);

                    foreach (var item in batch.BatchItems)
                    {
                        var tempBucket = bucketDa.GetByBucketId(item.BucketId);
                        if (tempBucket != null && !tempBucket.IsDeleted)
                        {
                            tempBucket.RemainingAmount -= item.UsedAmount;
                            if (tempBucket.RemainingAmount == 0)
                                tempBucket.IsEmpty = true;

                            bucketDa.Update(tempBucket);
                        }
                        else
                            throw new Exception("bucketId not valid");
                    }

                    //updateWorkProcess Status to inProcess
                    WorkProcessDataAccess workProcessDa = new WorkProcessDataAccess(tempContext, false);
                    var tempWorkProcess = workProcessDa.GetByWorkProcessStepId(batch.WorkProcessStepId);
                    tempWorkProcess.StatusId = (int)WorkProcessStatus.InProcess;

                    workProcessDa.Update(tempWorkProcess);

                    tempContext.Database.CommitTransaction();
                }
                else
                    tempContext.Database.RollbackTransaction();
            }
            catch (Exception exp)
            {
                tempContext.Database.RollbackTransaction();

                result = new ApiResult();
                result.IsSuccess = false;
                result.Message = exp.ToString();
                result.DataObject = exp;
            }

            return result;
        }

        public ApiResult DeleteByBatchId(int batchId)
        {
            ApiResult result = null;
            batchDa = new BatchDataAccess(null, true);

            try
            {
                var tempBath = batchDa.GetByBatchId(batchId);

                result = CanDeleteBatch(tempBath);

                if (result.IsSuccess)
                {
                    //update bucket amount;
                    BucketDataAccess bucketDa = new BucketDataAccess(batchDa.MainDbContext);

                    foreach (var item in tempBath.BatchItems)
                    {
                        var tempBucket = item.Bucket;// bucketDa.GetByBucketId(item.BucketId);
                        tempBucket.RemainingAmount += item.UsedAmount;
                        tempBucket.IsEmpty = false;
                        bucketDa.Update(tempBucket);
                    }

                    // check if there is no active batch for same workprocess, status of workprocess should changed to confirm
                    WorkProcessDataAccess workProcessDa = new WorkProcessDataAccess(batchDa.MainDbContext);
                    var tempWorkProcess = workProcessDa.GetByWorkProcessStepId(tempBath.WorkProcessStepId);
                    var tempBatchList = batchDa.GetBatchByWorkProcessId(tempWorkProcess.WorkProcessId);
                    if (tempBatchList.Where(w => w.BatchId != tempBath.BatchId && w.StatusId != (int)WorkProcessStatus.Cancel).Count() == 0)
                    {
                        tempWorkProcess.StatusId = (int)WorkProcessStatus.Confirm;
                        workProcessDa.Update(tempWorkProcess);
                    }

                    batchDa.Delete(tempBath);
                    batchDa.MainDbContext.Database.CommitTransaction();
                }
                else
                    batchDa.MainDbContext.Database.RollbackTransaction();

            }
            catch (Exception exp)
            {
                batchDa.MainDbContext.Database.RollbackTransaction();

                result = new ApiResult();
                result.IsSuccess = false;
                result.Message = exp.ToString();
                result.DataObject = exp;
            }


            return result;
        }

        public ApiResult Edit(Batch batch)
        {
            ApiResult result = null;

            batchDa = new BatchDataAccess(null, false);

            result = Validate(batch);

            if (result.IsSuccess)
                result.DataObject = batchDa.Update(batch);

            return result;
        }

        public ApiResult EditStatus(int batchId, BatchStatus batchStatus)
        {
            ApiResult result = null;

            batchDa = new BatchDataAccess(null, true);

            try
            {
                var tempBatch = batchDa.GetByBatchId(batchId);
                result = ValidateUpdateStatus(tempBatch, batchStatus);

                if (result.IsSuccess)
                {
                    tempBatch.StatusId = (int)batchStatus;
                    if (batchStatus == BatchStatus.Confirm)
                        tempBatch.BatchBarcode = CreateBatchBarcode(tempBatch);
                    else if (batchStatus == BatchStatus.Cancel)
                    {
                        // check if there is no active batch for same workprocess, status of workprocess should changed to confirm
                        WorkProcessDataAccess workProcessDa = new WorkProcessDataAccess(batchDa.MainDbContext);
                        var tempWorkProcess = workProcessDa.GetByWorkProcessStepId(tempBatch.WorkProcessStepId);
                        var tempBatchList = batchDa.GetBatchByWorkProcessId(tempWorkProcess.WorkProcessId);
                        if (tempBatchList.Where(w => w.BatchId != tempBatch.BatchId && w.StatusId != (int)WorkProcessStatus.Cancel).Count() == 0)
                        {
                            tempWorkProcess.StatusId = (int)WorkProcessStatus.Confirm;
                            workProcessDa.Update(tempWorkProcess);
                        }
                    }

                    result.DataObject = batchDa.Update(tempBatch);

                    batchDa.MainDbContext.Database.CommitTransaction();
                }
                else
                    batchDa.MainDbContext.Database.RollbackTransaction();
            }
            catch (Exception exp)
            {
                batchDa.MainDbContext.Database.RollbackTransaction();

                result = new ApiResult();
                result.IsSuccess = false;
                result.Message = exp.ToString();
                result.DataObject = exp;
            }

            return result;
        }

        #endregion

        #region [ Privtae Field(s) ]

        private BatchDataAccess batchDa = null;

        #endregion

        #region [ Privtae Method(s) ]

        private ApiResult Validate(Batch batch)
        {
            ApiResult result = new ApiResult();

            return result;
        }

        private ApiResult CanDeleteBatch(Batch batch)
        {
            ApiResult result = new ApiResult();

            if (batch.StatusId != (int)BatchStatus.Draft)
            {
                result.IsSuccess = false;
                result.Message = MessageResource.BatchDeleteStatusError;
            }

            return result;
        }

        private ApiResult ValidateUpdateStatus(Batch batch, BatchStatus batchStatus)
        {
            ApiResult result = new ApiResult();

            if (batchStatus == BatchStatus.Cancel)
            {
                if (batch.StatusId != (int)BatchStatus.Confirm)
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.BatchEditStatusNotValid;
                }
            }
            else if (((int)batchStatus) - batch.StatusId != 1)
            {
                result.IsSuccess = false;
                result.Message = MessageResource.BatchEditStatusNotValid;
            }

            return result;
        }

        private string CreateBatchBarcode(Batch batch)
        {
            var month = batch.CreateDate.ToString("MM");
            var day = batch.CreateDate.ToString("dd");

            string tempBarcode = $"batch-{batch.BatchId}-{batch.StaffId}-{batch.WorkProcessStepId}-{batch.CreateDate.Year}{month}{day}";
            return tempBarcode;
        }

        #endregion
    }
}
