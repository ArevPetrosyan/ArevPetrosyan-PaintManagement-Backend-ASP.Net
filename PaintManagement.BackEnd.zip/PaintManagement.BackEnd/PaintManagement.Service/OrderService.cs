﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Service
{
    public class OrderService : IOrderService
    {

        #region [ Constrcutor(s) ]

        public OrderService()
        {
            orderDa = new OrderDataAccess();
            orderItemDa = new OrderItemDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public List<Order> LoadActiveOrders()
        {
            List<Order> tempOrderList = null;

            tempOrderList = orderDa.GetOrderByIsDeleted(false);

            return tempOrderList;
        }

        public List<Order> LoadActiveOrderByCustomerId(int customerId)
        {
            List<Order> tempOrderList = null;

            tempOrderList = orderDa.GetOrderByCustomerId(customerId);

            return tempOrderList;
        }

        public List<Order> LoadActiveOrderByOrderStatusId(int orderStatusId)
        {
            List<Order> tempOrderList = null;

            tempOrderList = orderDa.GetOrderByOrderStatusId_IsDeleted(orderStatusId, false);

            return tempOrderList;
        }

        public Order LoadOrderById(int orderId)
        {
            Order tempOrder = null;

            tempOrder = orderDa.GetOrderById(orderId);

            return tempOrder;
        }

        public List<Order> LoadActiveOrderByWorkpieceId(int workpieceId)
        {
            List<Order> tempOrderList = null;

            tempOrderList = orderDa.GetOrderByWorkPieceId_IsDeleted(workpieceId, false);

            return tempOrderList;
        }

        public List<Order> LoadActiveOrderByPaintId(int paintId)
        {
            List<Order> tempOrderList = null;

            tempOrderList = orderDa.GetOrderByPaintId_IsDeleted(paintId, false);

            return tempOrderList;
        }

        public ApiResult Add(Order order)
        {
            ApiResult tempResult = null;

            tempResult = ValidateAddOrder(order);

            if (tempResult.IsSuccess)
                tempResult.DataObject = orderDa.Insert(order);

            return tempResult;
        }

        public ApiResult Edit(Order order)
        {
            ApiResult tempResult = null;

            tempResult = ValidateEditOrder(order);

            if (tempResult.IsSuccess)
                tempResult.DataObject = orderDa.Update(order);

            return tempResult;
        }

        public ApiResult DeleteByOrderId(int orderId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteOrder(orderId);

            if (tempResult.IsSuccess)
            {
                var temp = orderDa.DeleteByOrderId(orderId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        public ApiResult DeleteOrderItemByOrderItemIds(List<int> orderItemIds)
        {
            ApiResult tempResult = null;

            foreach (var item in orderItemIds)
            {
                tempResult = CanDeleteOrder(item);
                if (!tempResult.IsSuccess)
                    break;
            }

            if (tempResult == null || tempResult.IsSuccess)
                foreach (var item in orderItemIds)
                {
                    tempResult.DataObject = orderItemDa.DeleteByOrderItemId(item);
                }

            return tempResult;
        }

        #endregion

        #region [ Privtae Field(s) ]

        private OrderDataAccess orderDa = null;

        private OrderItemDataAccess orderItemDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidateAddOrder(Order order)
        {
            ApiResult tempResult = new ApiResult();

            if (order.OrderStatusId != (int)OrderStatus.Draft)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderAddNewOrderStatusIsNotValid;
            }

            if (string.IsNullOrWhiteSpace(order.OrderCode))
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderCodeIsNotValid;
            }

            if (order.DeliveryDate < DateTime.Today || order.CreateDate > order.DeliveryDate)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderDeliveryDateIsNotValid;
            }

            CustomerService customerService = new CustomerService();
            var tempCustomer = customerService.LoadByCustomerId(order.CustomerId);
            if (tempCustomer == null || tempCustomer.IsDeleted)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.CustomerIsNotValid;
            }

            tempResult = ValidateOrderItem(order);

            return tempResult;
        }

        private ApiResult ValidateEditOrder(Order order)
        {
            ApiResult tempResult = new ApiResult();

            if (string.IsNullOrWhiteSpace(order.OrderCode))
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderCodeIsNotValid;
            }

            if (order.DeliveryDate < DateTime.Today || order.CreateDate > order.DeliveryDate)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderDeliveryDateIsNotValid;
            }

            CustomerService customerService = new CustomerService();
            var tempCustomer = customerService.LoadByCustomerId(order.CustomerId);
            if (tempCustomer == null || tempCustomer.IsDeleted)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.CustomerIsNotValid;
            }

            tempResult = ValidateOrderItem(order);

            return tempResult;
        }

        private ApiResult ValidateOrderItem(Order order)
        {
            ApiResult tempResult = new ApiResult();

            if (order.OrderItems.Count == 0)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.OrderHasNoOrderItem;
            }
            else
            {
                WorkPieceService workpieceService = new WorkPieceService();
                PaintService paintService = new PaintService();

                WorkPiece tempWorkpiece = null;
                Paint tempPaint = null;

                foreach (var item in order.OrderItems)
                {
                    if (item.Amount <= 0)
                    {
                        tempResult.IsSuccess = false;
                        tempResult.Message = MessageResource.OrderItemAmountIsNotCorrect;
                        break;
                    }

                    tempWorkpiece = workpieceService.LoadById(item.WorkPieceId);
                    if (tempWorkpiece == null || tempWorkpiece.IsDeleted || tempWorkpiece.CustomerId != order.CustomerId)
                    {
                        tempResult.IsSuccess = false;
                        tempResult.Message = MessageResource.WorkPieceIsNotValid;
                        break;
                    }

                    tempPaint = paintService.LoadByPaintId(item.PaintId);
                    if (tempPaint == null || tempPaint.IsDeleted)
                    {
                        tempResult.IsSuccess = false;
                        tempResult.Message = MessageResource.PaintIsNotValid;
                        break;
                    }

                }
            }

            return tempResult;
        }

        private ApiResult CanDeleteOrder(int orderId)
        {
            ApiResult tempResult = new ApiResult();



            return tempResult;
        }

        private ApiResult CanDeleteOrderItem(int orderItemId)
        {
            ApiResult tempResult = new ApiResult();


            return tempResult;
        }

        #endregion
    }
}
