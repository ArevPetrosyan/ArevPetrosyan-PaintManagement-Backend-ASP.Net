﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.Service
{
    public class StaffService : IStaffService
    {

        #region [ Constructor(s) ]

        public StaffService()
        {
            staffDa = new StaffDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public List<Staff> LoadActiveStaff()
        {
            List<Staff> resultList = null;

            resultList = staffDa.GetAllStaffByIsDeleted(false);

            return resultList;
        }

        public Staff LoadById(int staffId)
        {
            Staff result = null;

            result = staffDa.GetById(staffId);

            return result;
        }

        public Staff LoadByAuthenticationBarcode(string authenticationBarcode)
        {
            Staff result = null;

            result = staffDa.GetByAuthenticationBarcode(authenticationBarcode);

            return result;
        }

        public Staff LoadByAuthenticationTagId(string authenticationTagId)
        {
            Staff result = null;

            result = staffDa.GetByAuthenticationTagId(authenticationTagId);

            return result;
        }

        public ApiResult Add(Staff staff)
        {
            ApiResult tempResult = null;

            tempResult = ValidateStaff(staff);

            if (tempResult.IsSuccess)
                tempResult.DataObject = staffDa.Insert(staff);

            return tempResult;
        }

        public ApiResult Edit(Staff staff)
        {
            ApiResult tempResult = null;

            tempResult = ValidateStaff(staff);

            if (tempResult.IsSuccess)
                tempResult.DataObject = staffDa.Update(staff);

            return tempResult;
        }

        public ApiResult DeleteByStaffId(int staffId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteStaff(staffId);

            if (tempResult.IsSuccess)
            {
                var temp = staffDa.DeleteByStaffId(staffId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        StaffDataAccess staffDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidateStaff(Staff staff)
        {
            ApiResult tempResult = new ApiResult();

            if (string.IsNullOrWhiteSpace(staff.FirstName) || string.IsNullOrWhiteSpace(staff.LastName))
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.StaffFirstnameLastnameCannotBeEmpty;
            }

            return tempResult;
        }

        private ApiResult CanDeleteStaff(int staffId)
        {
            ApiResult tempResult = new ApiResult();


            return tempResult;
        }

        #endregion

    }
}
