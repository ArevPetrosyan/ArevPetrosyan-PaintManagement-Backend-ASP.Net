﻿using Microsoft.IdentityModel.Tokens;
using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.Common.Messages;

namespace PaintManagement.Service
{
    public class SupplierService : ISupplierService
    {
        #region [ Constructor(s) ]

        public SupplierService()
        {
            supplierDa = new SupplierDataAccess();
        }

        #endregion

        #region [ Public Method(s) ] 

        public List<Supplier> LoadAllSupplier()
        {

            List<Supplier> tempList = null;

            tempList = supplierDa.GetAllSupplier();

            return tempList;
        }

        public Supplier LoadSupplierById(int supplierId)
        {
            Supplier temp = null;

            temp = supplierDa.GetById(supplierId);

            return temp;
        }

        public List<Supplier> LoadActiveSuppliers()
        {
            List<Supplier> tempList = null;

            tempList = supplierDa.GetByIsDeleted(false);

            return tempList;
        }

        public ApiResult Add(Supplier supplier)
        {
            ApiResult tempResult = null;

            tempResult = ValidateSupplier(supplier);

            if (tempResult.IsSuccess)
                tempResult.DataObject = supplierDa.Insert(supplier);

            return tempResult;
        }

        public ApiResult Edit(Supplier supplier)
        {
            ApiResult tempResult = null;

            tempResult = ValidateSupplier(supplier);

            if (tempResult.IsSuccess)
                tempResult.DataObject = supplierDa.Update(supplier);

            return tempResult;
        }

        public ApiResult DeleteBySupplierId(int supplierId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteSupplier(supplierId);

            if (tempResult.IsSuccess)
            {
                var temp = supplierDa.DeleteBySupplierId(supplierId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private SupplierDataAccess supplierDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidateSupplier(Supplier supplier)
        {
            ApiResult tempResult = new ApiResult();

            if (string.IsNullOrWhiteSpace(supplier.SupplierName))
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.SupplierNameCannotBeEmpty;
            }

            return tempResult;
        }

        private ApiResult CanDeleteSupplier(int supplierId)
        {
            ApiResult tempResult = new ApiResult();

            PaintService printService = new PaintService();

            var paintList = printService.LoadAcitvePaintBySupplierId(supplierId);
            if (paintList != null && paintList.Count > 0)
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.SupplierHasActivePaint;
            }

            return tempResult;
        }

        #endregion
    }
}
