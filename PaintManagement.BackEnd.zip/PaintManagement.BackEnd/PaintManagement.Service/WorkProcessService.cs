﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class WorkProcessService : IWorkProcessService
    {
        #region [ Constructor(s) ]

        public WorkProcessService()
        {
            workProcessDa = new WorkProcessDataAccess(null);
            workProcessStepDa = new WorkProcessStepDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public List<WorkProcess> LoadAll()
        {
            List<WorkProcess> result = null;

            result = workProcessDa.GetAllWorkProcess();

            return result;
        }

        public List<WorkProcess> LoadAllActive()
        {
            List<WorkProcess> result = null;

            var temp = workProcessDa.GetAllWorkProcess();
            if (temp != null)
                result = temp.Where(w => !w.IsDeleted).ToList();

            return result;
        }

        public WorkProcess LoadById(int workProcessId)
        {
            WorkProcess result = null;

            result = workProcessDa.GetById(workProcessId);

            return result;
        }

        public WorkProcess LoadByWorkProcessStepId(int workProcessStepId)
        {
            WorkProcess result = null;

            result = workProcessDa.GetByWorkProcessStepId(workProcessStepId);

            return result;
        }

        public ApiResult Add(WorkProcess workProcess)
        {
            ApiResult tempResult = null;

            tempResult = ValidateWorkProcess(workProcess);

            if (tempResult.IsSuccess)
                tempResult.DataObject = workProcessDa.Insert(workProcess);

            return tempResult;
        }

        public ApiResult Edit(WorkProcess workProcess)
        {
            ApiResult tempResult = null;

            tempResult = ValidateWorkProcess(workProcess);

            if (tempResult.IsSuccess)
                tempResult.DataObject = workProcessDa.Update(workProcess);

            return tempResult;
        }

        public ApiResult EditStatus(int workProcessId, WorkProcessStatus workProcessStatus)
        {
            ApiResult tempResult = null;

            var tempWorkProcess = workProcessDa.GetById(workProcessId);
            if (tempWorkProcess != null)
            {
                tempResult = ValidateUpdateStatus(tempWorkProcess, workProcessStatus);
                if (tempResult.IsSuccess)
                {
                    tempWorkProcess.StatusId = (int)workProcessStatus;
                    tempResult.DataObject = workProcessDa.Update(tempWorkProcess);
                }
            }

            return tempResult;
        }

        public ApiResult DeleteByWorkProcessId(int workProcessId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteWorkProcess(workProcessId);
            if (tempResult.IsSuccess)
            {
                var temp = workProcessDa.DeleteByWorkProcessId(workProcessId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        public ApiResult DeleteWorkProcessStepByWorkProcessStepId(int workProcessStepId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteWorkProcessStep(workProcessStepId);
            if (tempResult.IsSuccess)
                tempResult.DataObject = workProcessStepDa.DeleteByWorkProcessStepId(workProcessStepId);

            return tempResult;
        }

        public ApiResult DeleteWorkProcessStepByWorkProcessStepIds(List<int> workProcessStepIds)
        {
            ApiResult tempResult = null;
            if (workProcessStepIds != null && workProcessStepIds.Count > 0)
            {
                foreach (var item in workProcessStepIds)
                {
                    tempResult = CanDeleteWorkProcessStep(item);
                    if (!tempResult.IsSuccess)
                        break;
                }

                if (tempResult == null || tempResult.IsSuccess)
                    foreach (var item in workProcessStepIds)
                    {
                        tempResult.DataObject = workProcessStepDa.DeleteByWorkProcessStepId(item);
                    }
            }

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private WorkProcessDataAccess workProcessDa = null;
        private WorkProcessStepDataAccess workProcessStepDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidateWorkProcess(WorkProcess workProcess)
        {
            ApiResult result = new ApiResult();

            //TODO: 

            return result;
        }

        private ApiResult CanDeleteWorkProcess(int workProcessId)
        {
            ApiResult result = new ApiResult();

            //TODO:

            return result;
        }

        private ApiResult CanDeleteWorkProcessStep(int workProcessStepId)
        {
            ApiResult result = new ApiResult();

            //TODO:

            return result;
        }

        private ApiResult ValidateUpdateStatus(WorkProcess workProcess, WorkProcessStatus workProcessStatus)
        {
            ApiResult result = new ApiResult();

            if (workProcessStatus == WorkProcessStatus.Cancel  )
            {
                if (workProcess.StatusId != (int)((char)workProcessStatus))
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.WorkProcessEditStatusNoValid;
                }
                else
                {
                    BatchDataAccess batchDa = new BatchDataAccess();
                    var tempBatch = batchDa.GetBatchByWorkProcessId(workProcess.WorkProcessId);
                    if (tempBatch != null && tempBatch.Any(a => a.StatusId != (int)BatchStatus.Cancel))
                    {
                        result.IsSuccess = false;
                        result.Message = MessageResource.WorkProcessUpdateStatusErrorHasActiveBatch;
                    }
                }
            }
            else
            {
                if (((int)workProcessStatus) - workProcess.StatusId != 1)
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.WorkProcessEditStatusNoValid;
                }
            }
                

            return result;
        }

        #endregion
    }
}

