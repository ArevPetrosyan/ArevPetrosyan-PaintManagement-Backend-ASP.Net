﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class CustomerService : ICustomerService
    {

        #region [ Constructor(s) ] 

        public CustomerService()
        {
            customerDa = new CustomerDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public List<Customer> LoadAllCustomer()
        {

            List<Customer> tempList = null;

            tempList = customerDa.GetAllCustomer();

            return tempList;
        }

        public Customer LoadByCustomerId(int customerId)
        {
            Customer temp = null;

            temp = customerDa.GetByCustomerId(customerId);

            return temp;
        }

        public List<Customer> LoadActiveCustomers()
        {
            List<Customer> tempList = null;

            tempList = customerDa.GetByIsDeleted(false);

            return tempList;
        }

        public ApiResult Add(Customer customer)
        {
            ApiResult tempResult = null;

            tempResult = Validate(customer);

            if (tempResult.IsSuccess)
                tempResult.DataObject = customerDa.Insert(customer);

            return tempResult;
        }

        public ApiResult Edit(Customer customer)
        {
            ApiResult tempResult = null;

            tempResult = Validate(customer);

            if (tempResult.IsSuccess)
                tempResult.DataObject = customerDa.Update(customer);

            return tempResult;
        }

        public ApiResult DeleteByCustomerId(int customerId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteCustomer(customerId);

            if (tempResult.IsSuccess)
            {
                var temp = customerDa.DeleteByCustomerId(customerId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private CustomerDataAccess customerDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult Validate(Customer customer)
        {
            ApiResult result = new ApiResult();

            if (string.IsNullOrWhiteSpace(customer.CustomerName))
            {
                result.IsSuccess = false;
                result.Message = MessageResource.CustomerNameCannotBeEmpty;
            }

            return result;
        }

        private ApiResult CanDeleteCustomer(int customerId)
        {
            ApiResult result = new ApiResult();

            OrderService orderService = new OrderService();

            var tempOrderList = orderService.LoadActiveOrderByCustomerId(customerId);
            if (tempOrderList != null && tempOrderList.Count > 0)
            {
                if (tempOrderList.Where(w => w.OrderStatusId != (int)OrderStatus.Cancel &&
                                  w.OrderStatusId != (int)OrderStatus.Done).ToList().Count > 0)
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.CustomerHasActiveOrder;
                }
            }

            return result;
        }

        #endregion

    }
}
