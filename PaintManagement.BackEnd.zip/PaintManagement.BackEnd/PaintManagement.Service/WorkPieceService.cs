﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class WorkPieceService : IWorkPieceService
    {

        #region [ Constructor(s) ]

        public WorkPieceService()
        {
            workPieceDa = new WorkPieceDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public List<WorkPiece> LoadActiveWorkPieces()
        {
            List<WorkPiece> tempList = null;

            tempList = workPieceDa.GetByIsDeleted(false);

            return tempList;
        }

        public List<WorkPiece> LoadAllWorkPiece()
        {
            List<WorkPiece> tempList = null;

            tempList = workPieceDa.GetAllWorkPiece();

            return tempList;
        }

        public List<WorkPiece> LoadActiveWorkPieceByCustomerId(int customerId)
        {
            List<WorkPiece> tempList = null;

            tempList = workPieceDa.GetByCustomerId_IsDeleted(customerId, false);

            return tempList;
        }

        public WorkPiece LoadById(int workPieceId)
        {
            WorkPiece temp = null;

            temp = workPieceDa.GetById(workPieceId);

            return temp;
        }

        public ApiResult Add(WorkPiece workPiece)
        {
            ApiResult tempResult = null;

            tempResult = ValidateWorkPiece(workPiece);

            if (tempResult.IsSuccess)
                tempResult.DataObject = workPieceDa.Insert(workPiece);

            return tempResult;
        }

        public ApiResult DeleteByWorkPieceId(int workPieceId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeleteWorkPiece(workPieceId);
            if (tempResult.IsSuccess)
            {
                var temp = workPieceDa.DeleteByWorkPieceId(workPieceId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        public ApiResult Edit(WorkPiece workPiece)
        {
            ApiResult tempResult = null;

            tempResult = ValidateWorkPiece(workPiece);

            if (tempResult.IsSuccess)
                tempResult.DataObject = workPieceDa.Update(workPiece);

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private WorkPieceDataAccess workPieceDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidateWorkPiece(WorkPiece workPiece)
        {
            ApiResult result = new ApiResult();

            if (string.IsNullOrWhiteSpace(workPiece.WorkPieceName))
            {
                result.IsSuccess = false;
                result.Message = MessageResource.WorkPieceNameCannotBeEmpty;
            }
            else
            {
                CustomerService customerService = new CustomerService();
                Customer tempCustomer = customerService.LoadByCustomerId(workPiece.CustomerId);
                if (tempCustomer == null || tempCustomer.IsDeleted)
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.CustomerIsNotValid;
                }
            }

            return result;
        }

        private ApiResult CanDeleteWorkPiece(int workpieceId)
        {
            ApiResult result = new ApiResult();

            OrderService orderService = new OrderService();
            var tempOrderList = orderService.LoadActiveOrderByWorkpieceId(workpieceId);
            if (tempOrderList != null && tempOrderList.Count > 0)
            {
                if (tempOrderList.Where(w => w.OrderStatusId != (int)OrderStatus.Cancel &&
                                   w.OrderStatusId != (int)OrderStatus.Done).ToList().Count > 0)
                {
                    result.IsSuccess = false;
                    result.Message = MessageResource.CustomerHasActiveOrder;
                }
            }

            return result;
        }


        #endregion

    }
}
