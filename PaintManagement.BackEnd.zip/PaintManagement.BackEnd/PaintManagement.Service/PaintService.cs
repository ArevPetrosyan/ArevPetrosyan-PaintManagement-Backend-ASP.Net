﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Utilities.Enumerations;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class PaintService : IPaintService
    {
        #region [ Constructor(s) ]

        public PaintService()
        {
            paintDa = new PaintDataAccess();
            paintM2MDa = new PaintM2MDataAccess();
        }

        #endregion

        #region [ Public Method(s) ]

        public Paint LoadByPaintId(int paintId)
        {
            Paint result = null;

            result = paintDa.GetByPaintId(paintId);

            return result;
        }

        public List<Paint> LoadConnectedPaintByPaintId(int paintId)
        {
            List<Paint> tempList = null;

            tempList = paintDa.GetConnectedPaintByPaintId(paintId);

            return tempList;
        }

        public List<Paint> LoadAcitvePaintBySupplierId(int supplierId)
        {
            List<Paint> tempList = null;

            tempList = paintDa.GetPaintBySupplierId_IsDeleted(supplierId, false);

            return tempList;
        }

        public List<Paint> LoadActivePaint()
        {
            List<Paint> tempList = null;

            tempList = paintDa.GetPaintByIsDeleted_SupplierIsDeleted(false, false);

            return tempList;
        }

        public ApiResult Add(Paint paint)
        {
            ApiResult tempResult = null;

            tempResult = ValidatePaint(paint);
            if (tempResult.IsSuccess)
                tempResult.DataObject = paintDa.Insert(paint);

            return tempResult;
        }

        public ApiResult Edit(Paint paint)
        {
            ApiResult tempResult = null;

            tempResult = ValidatePaint(paint);
            if (tempResult.IsSuccess)
                tempResult.DataObject = paintDa.Update(paint);

            return tempResult;
        }

        public ApiResult DeleteByPaintId(int paintId)
        {
            ApiResult tempResult = null;

            tempResult = CanDeletePaint(paintId);
            if (tempResult.IsSuccess)
            {
                var temp = paintDa.DeleteByPaintId(paintId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        public ApiResult AddConnectedPaint(PaintM2M paintM2M)
        {
            ApiResult tempResult = new ApiResult();

            tempResult.DataObject = paintM2MDa.InsertPaintM2M(paintM2M);

            return tempResult;
        }

        public ApiResult DeleteConnectedPaint(PaintM2M paintM2M)
        {
            ApiResult tempResult = new ApiResult();

            tempResult.DataObject = paintM2MDa.DeletePaintM2M(paintM2M);

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private PaintDataAccess paintDa = null;

        private PaintM2MDataAccess paintM2MDa = null;

        #endregion

        #region [ Private Method(s) ]

        private ApiResult ValidatePaint(Paint paint)
        {
            ApiResult tempResult = new ApiResult();

            if (string.IsNullOrWhiteSpace(paint.PaintName))
            {
                tempResult.IsSuccess = false;
                tempResult.Message = MessageResource.PaintNameCannotBeEmpty;
            }
            else
            {
                SupplierService supplierService = new SupplierService();
                Supplier tempSupplier = supplierService.LoadSupplierById(paint.SupplierId);
                if (tempSupplier == null || tempSupplier.IsDeleted)
                {
                    tempResult.IsSuccess = false;
                    tempResult.Message = MessageResource.SupplierIsNotValid;
                }
            }

            return tempResult;
        }

        private ApiResult CanDeletePaint(int paintId)
        {
            ApiResult tempResult = new ApiResult();

            OrderService orderService = new OrderService();
            var tempOrderList = orderService.LoadActiveOrderByPaintId(paintId);

            if (tempOrderList != null && tempOrderList.Count > 0)
            {
                if (tempOrderList.Where(w => w.OrderStatusId != (int)OrderStatus.Cancel &&
                                        w.OrderStatusId != (int)OrderStatus.Done).ToList().Count > 0)
                {
                    tempResult.IsSuccess = false;
                    tempResult.Message = MessageResource.PaintHasActiveOrder;
                }
            }

            return tempResult;
        }

        #endregion

    }
}
