﻿using PaintManagement.Common;
using PaintManagement.Common.Interfaces.Services;
using PaintManagement.Common.Messages;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Models.DB.Views;
using PaintManagement.Common.Utilities.Helpers;
using PaintManagement.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaintManagement.Service
{
    public class BucketService : IBucketService
    {

        #region [ Constructor(s) ]

        public BucketService()
        {

        }

        #endregion

        #region [ Public Method(s) ]

        public List<BucketView> LoadActiveBucketByBestBeforeRemainDays(int remainDays)
        {
            List<BucketView> resultList = null;
            bucketDa = new BucketDataAccess(null, false);
            resultList = bucketDa.GetByBestBefore_IsDeleted_IsEmpty_RemainDays(remainDays, false, false);

            return resultList;
        }

        public List<Bucket> LoadAcitveBucketByPaintId(int paintId)
        {
            List<Bucket> tempList = null;

            if (paintId > 0)
            {
                bucketDa = new BucketDataAccess(null, false);
                tempList = bucketDa.GetBucketByPaintId_IsDeleted(paintId, false);
            }

            return tempList;
        }

        public List<Bucket> LoadBucketByBatchId(int batchId)
        {
            List<Bucket> tempList = null;

            if (batchId > 0)
            {
                bucketDa = new BucketDataAccess(null, false);
                tempList = bucketDa.GetBucketByBatchId(batchId);
            }

            return tempList;
        }

        public Bucket GetByBucketId(int bucketId)
        {
            Bucket temp = null;

            if (bucketId > 0)
            {
                bucketDa = new BucketDataAccess(null, false);
                temp = bucketDa.GetByBucketId(bucketId);
            }

            return temp;
        }

        public Bucket GetByBarcode(string barcode)
        {
            Bucket temp = null;

            if (!string.IsNullOrEmpty(barcode))
            {
                bucketDa = new BucketDataAccess(null, false);
                temp = bucketDa.GetByBarcode(barcode);
            }

            return temp;
        }

        public ApiResult Add(Bucket bucket, uint bucketCount = 1)
        {
            ApiResult result = null;

            bucketDa = new BucketDataAccess(null, false);
            List<Bucket> bucketList = new List<Bucket>();

            try
            {
                result = ValidateBucket(bucket);

                if (result.IsSuccess)
                {
                    for (int i = 1; i < bucketCount + 1; i++)
                    {
                        var tempBucket = new Bucket();
                        tempBucket.Amount = bucket.Amount;
                        tempBucket.BestBefore = bucket.BestBefore;
                        tempBucket.ManufacturerBatchNumber = bucket.ManufacturerBatchNumber;
                        tempBucket.PaintId = bucket.PaintId;
                        tempBucket.Paint = bucket.Paint;
                        tempBucket.ProductionDate = bucket.ProductionDate;
                        tempBucket.RemainingAmount = bucket.RemainingAmount;
                        tempBucket.Barcode = BarcodeHelper.CreateBucketBarcode(tempBucket);
                        bucketList.Add(tempBucket);
                    }

                    var rowAffect = bucketDa.Insert(bucketList);
                    if (rowAffect > 0)
                        result.DataObject = bucketList;

                    //bucketDa.MainDbContext.Database.CommitTransaction();
                }
                //else
                //    bucketDa.MainDbContext.Database.RollbackTransaction();
            }
            catch (Exception exp)
            {
                //bucketDa.MainDbContext.Database.RollbackTransaction();

                result = new ApiResult();
                result.IsSuccess = false;
                result.Message = exp.ToString();
                result.DataObject = exp;
            }

            return result;
        }

        public ApiResult Edit(Bucket bucket)
        {
            ApiResult tempResult = null;

            bucketDa = new BucketDataAccess(null, false);

            tempResult = ValidateBucket(bucket);

            if (tempResult.IsSuccess)
                tempResult.DataObject = bucketDa.Update(bucket);

            return tempResult;
        }

        public ApiResult DeleteByBucketId(int bucketId)
        {
            ApiResult tempResult = null;

            bucketDa = new BucketDataAccess(null, false);

            tempResult = CanDeleteBucket(bucketId);
            if (tempResult.IsSuccess)
            {
                var temp = bucketDa.DeleteByBucketId(bucketId);
                if (temp != null)
                    tempResult.DataObject = temp;
                else
                    tempResult.IsSuccess = false;
            }

            return tempResult;
        }

        #endregion

        #region [ Private Field(s) ]

        private BucketDataAccess bucketDa = null;

        #endregion

        #region[ Private Method(s) ]

        private ApiResult ValidateBucket(Bucket bucket)
        {
            ApiResult result = new ApiResult();

            if (bucket.Amount <= 0 || bucket.RemainingAmount < 0 || bucket.Amount < bucket.RemainingAmount)
            {
                result.IsSuccess = false;
                result.Message = MessageResource.BucketAmountNotCorrect;
            }

            PaintService paintService = new PaintService();
            var paint = paintService.LoadByPaintId(bucket.PaintId);
            if (paint == null || paint.IsDeleted)
            {
                result.IsSuccess = false;
                result.Message = MessageResource.PaintIsNotValid;
            }

            if (bucket.ProductionDate > bucket.BestBefore)
            {
                result.IsSuccess = false;
                result.Message = MessageResource.PaintProductionDateIsNotValid;
            }

            return result;
        }

        private ApiResult CanDeleteBucket(int bucketId)
        {
            ApiResult result = new ApiResult();

            //TODO: need to check if possible to delete bucket or not

            return result;
        }

        #endregion

    }
}
