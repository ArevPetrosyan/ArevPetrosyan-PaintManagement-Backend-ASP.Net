﻿using Microsoft.EntityFrameworkCore;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaintManagement.DataAccess
{
    public class MainDBContext : DbContext
    {
        #region [ Constructor(s) ]

        public MainDBContext(string connectionString) : base(GetOptions(connectionString))
        {

        }

        #endregion

        #region [ Public Property(s) ]

        public DbSet<Supplier> Supplier { get; set; }

        public DbSet<Customer> Customer { get; set; }

        public DbSet<Paint> Paint { get; set; }

        public DbSet<PaintM2M> PaintM2M { get; set; }

        public DbSet<Bucket> Bucket { get; set; }

        public DbSet<WorkPiece> WorkPiece { get; set; }

        public DbSet<Order> Order { get; set; }

        public DbSet<OrderItem> OrderItem { get; set; }

        public DbSet<Staff> Staff { get; set; }

        public DbSet<Batch> Batch { get; set; }

        public DbSet<BatchItem> BatchItem { get; set; }

        public DbSet<WorkProcess> WorkProcess { get; set; }

        public DbSet<WorkProcessStep> WorkProcessStep { get; set; }

        #endregion

        #region [ Private Method(s) ]

        private static DbContextOptions GetOptions(string connectionString)
        {
            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder(), connectionString).Options;
        }

        #endregion

    }
}
