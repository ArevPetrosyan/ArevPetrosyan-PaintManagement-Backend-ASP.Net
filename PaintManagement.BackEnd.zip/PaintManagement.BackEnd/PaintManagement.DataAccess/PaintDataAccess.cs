﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class PaintDataAccess
    {

        #region [ Constructor(s) ]

        public PaintDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        public Paint GetByPaintId(int paintId)
        {
            Paint temp = null;

            var query = from paint in mainDbContext.Paint
                        join supplier in mainDbContext.Supplier
                        on paint.SupplierId equals supplier.SupplierId
                        where paint.PaintId == paintId
                        select new Paint
                        {
                            PaintId = paint.PaintId,
                            PaintName = paint.PaintName,
                            PaintTypeId = paint.PaintTypeId,
                            SupplierId = paint.SupplierId,
                            Supplier = supplier,
                            SolventContent = paint.SolventContent,
                            Color = paint.Color,
                            OrderNumber = paint.OrderNumber
                        };

            temp = query.SingleOrDefault();

            return temp;
        }

        public List<Paint> GetConnectedPaintByPaintId(int paintId)
        {
            List<Paint> result = null;

            var query = from paint in mainDbContext.Paint

                        join paintM2M in mainDbContext.PaintM2M
                        on paint.PaintId equals paintM2M.ConnectedPaintId

                        join supplier in mainDbContext.Supplier
                        on paint.SupplierId equals supplier.SupplierId

                        where paintM2M.MainPaintId == paintId
                        select new Paint
                        {
                            PaintId = paint.PaintId,
                            PaintName = paint.PaintName,
                            PaintTypeId = paint.PaintTypeId,
                            SupplierId = paint.SupplierId,
                            Supplier = supplier,
                            SolventContent = paint.SolventContent,
                            Color = paint.Color,
                            OrderNumber = paint.OrderNumber
                        };

            result = query.ToList();

            return result;
        }

        public List<Paint> GetPaintBySupplierId_IsDeleted(int supplierId, bool isDeleted)
        {
            List<Paint> tempList = null;

            var query = from paint in mainDbContext.Paint
                        join supplier in mainDbContext.Supplier
                        on paint.SupplierId equals supplier.SupplierId
                        where paint.SupplierId == supplierId
                        && paint.IsDeleted == isDeleted
                        select new Paint
                        {
                            PaintId = paint.PaintId,
                            PaintName = paint.PaintName,
                            PaintTypeId = paint.PaintTypeId,
                            SupplierId = paint.SupplierId,
                            Supplier = supplier,
                            SolventContent = paint.SolventContent,
                            Color = paint.Color,
                            OrderNumber = paint.OrderNumber
                        };

            tempList = query.ToList();

            return tempList;
        }

        public List<Paint> GetPaintByIsDeleted_SupplierIsDeleted(bool isDeleted, bool supplierIsDeleted)
        {
            List<Paint> tempList = null;

            var query = from paint in mainDbContext.Paint
                        join supplier in mainDbContext.Supplier
                        on paint.SupplierId equals supplier.SupplierId
                        where paint.IsDeleted == isDeleted
                        && supplier.IsDeleted == supplierIsDeleted
                        select new Paint
                        {
                            PaintId = paint.PaintId,
                            PaintName = paint.PaintName,
                            PaintTypeId = paint.PaintTypeId,
                            SupplierId = paint.SupplierId,
                            Supplier = supplier,
                            SolventContent = paint.SolventContent,
                            Color = paint.Color,
                            OrderNumber = paint.OrderNumber
                        };

            tempList = query.ToList();

            return tempList;
        }

        public int Update(Paint paint)
        {
            int rowAffected = 0;

            mainDbContext.Update(paint);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Insert(Paint paint)
        {
            int rowAffected = 0;

            mainDbContext.Add(paint);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public Paint DeleteByPaintId(int paintId)
        {
            Paint result = null;

            var query = from paint in mainDbContext.Paint
                        where paint.PaintId == paintId
                        select paint;

            var tempPaint = query.SingleOrDefault();
            if (tempPaint != null)
            {
                tempPaint.IsDeleted = true;

                mainDbContext.Update(tempPaint);
                var rowAffected = mainDbContext.SaveChanges();

                if (rowAffected > 0)
                    result = tempPaint;
            }

            return result;
        }

        public int InsertPaintM2M(PaintM2M paintM2M)
        {
            int rowAffected = 0;

            mainDbContext.Add(paintM2M);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int DeletePaintM2M(PaintM2M paintM2M)
        {
            int rowAffected = 0;

            var query = from paintm2m in mainDbContext.PaintM2M
                        where paintm2m.MainPaintId == paintM2M.MainPaintId
                           && paintm2m.ConnectedPaintId == paintM2M.ConnectedPaintId
                        select paintm2m;

            var tempPaint = query.SingleOrDefault();

            if (tempPaint != null)
            {
                mainDbContext.Add(paintM2M);
                rowAffected = mainDbContext.SaveChanges();
            }

            return rowAffected;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion

    }
}
