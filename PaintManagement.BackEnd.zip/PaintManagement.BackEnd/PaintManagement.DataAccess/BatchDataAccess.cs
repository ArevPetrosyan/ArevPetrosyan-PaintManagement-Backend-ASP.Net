﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace PaintManagement.DataAccess
{
    public class BatchDataAccess
    {

        #region [ Constructor(s) ]

        public BatchDataAccess(MainDBContext dbContext = null, bool startNewTransaction = false)
        {
            if (dbContext != null)
                this.mainDbContext = dbContext;
            else
            {
                this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
                if (startNewTransaction)
                {
                    _transaction = this.mainDbContext.Database.BeginTransaction();
                }
            }
        }

        #endregion

        #region [ Public Property(s) ]

        public MainDBContext MainDbContext { get => mainDbContext; }

        #endregion

        #region [ Public Method(s) ]

        public Batch GetByBatchId(int batchId)
        {
            Batch temp = null;

            var query = from batch in mainDbContext.Batch.Include("BatchItems.Bucket").Include("BatchItems.Bucket.Paint")
                        join st in mainDbContext.Staff
                        on batch.StaffId equals st.StaffId
                        where batch.BatchId == batchId
                        select new Batch
                        {
                            BatchId = batch.BatchId,
                            StaffId = batch.StaffId,
                            CreateDate = batch.CreateDate,
                            WorkProcessStepId = batch.WorkProcessStepId,
                            WorkProcessStep = batch.WorkProcessStep,
                            StatusId = batch.StatusId,
                            BatchBarcode = batch.BatchBarcode,
                            Staff = batch.Staff,
                            BatchItems = batch.BatchItems
                        };

            temp = query.SingleOrDefault();

            return temp;
        }

        public List<Batch> GetBatchByStaffId(int staffId)
        {
            List<Batch> temp = null;

            var query = from batch in mainDbContext.Batch.Include("BatchItems.Bucket").Include("BatchItems.Bucket.Paint")
                        join st in mainDbContext.Staff
                        on batch.StaffId equals st.StaffId
                        where batch.StaffId == staffId
                        select new Batch
                        {
                            BatchId = batch.BatchId,
                            StaffId = batch.StaffId,
                            CreateDate = batch.CreateDate,
                            WorkProcessStepId = batch.WorkProcessStepId,
                            WorkProcessStep = batch.WorkProcessStep,
                            StatusId = batch.StatusId,
                            BatchBarcode = batch.BatchBarcode,
                            Staff = batch.Staff,
                            BatchItems = batch.BatchItems
                        };

            temp = query.ToList();

            return temp;
        }

        public List<Batch> GetBatchByWorkProcessId(int workprocessId)
        {
            List<Batch> temp = null;

            var query = from batch in mainDbContext.Batch.Include("BatchItems.Bucket").Include("BatchItems.Bucket.Paint")
                        join workProcessStep in mainDbContext.WorkProcessStep
                            on batch.WorkProcessStepId equals workProcessStep.WorkProcessStepId
                        join workprocess in mainDbContext.WorkProcess
                            on workProcessStep.WorkProcessId equals workprocess.WorkProcessId
                        where workprocess.WorkProcessId == workprocessId

                        select new Batch
                        {
                            BatchId = batch.BatchId,
                            StaffId = batch.StaffId,
                            CreateDate = batch.CreateDate,
                            WorkProcessStepId = batch.WorkProcessStepId,
                            WorkProcessStep = batch.WorkProcessStep,
                            StatusId = batch.StatusId,
                            BatchBarcode = batch.BatchBarcode,
                            Staff = batch.Staff,
                            BatchItems = batch.BatchItems
                        };

            temp = query.Distinct().ToList();

            return temp;
        }

        public List<Batch> GetAllBatch()
        {
            List<Batch> temp = null;

            var query = from batch in mainDbContext.Batch.Include("BatchItems.Bucket").Include("BatchItems.Bucket.Paint")
                        select new Batch
                        {
                            BatchId = batch.BatchId,
                            StaffId = batch.StaffId,
                            CreateDate = batch.CreateDate,
                            WorkProcessStepId = batch.WorkProcessStepId,
                            WorkProcessStep = batch.WorkProcessStep,
                            StatusId = batch.StatusId,
                            BatchBarcode = batch.BatchBarcode,
                            Staff = batch.Staff,
                            BatchItems = batch.BatchItems
                        };


            temp = query.ToList();

            return temp;
        }

        public int Insert(Batch batch)
        {
            int rowAffected = 0;

            mainDbContext.Add(batch);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Update(Batch batch)
        {
            int rowAffected = 0;

            mainDbContext.Update(batch);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public void Delete(Batch batch)
        {
            mainDbContext.Remove(batch);
            mainDbContext.SaveChanges();
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;
        private readonly IDbContextTransaction _transaction = null;

        #endregion
    }
}
