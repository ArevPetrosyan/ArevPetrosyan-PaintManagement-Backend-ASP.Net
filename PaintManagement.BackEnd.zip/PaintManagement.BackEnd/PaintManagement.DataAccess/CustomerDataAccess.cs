﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class CustomerDataAccess
    {

        #region [ Constructor(s) ]

        public CustomerDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Customer> GetAllCustomer()
        {
            List<Customer> result = null;

            var query = from cus in mainDbContext.Customer
                        select cus;

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public Customer GetByCustomerId(int customerId)
        {
            Customer result = null;

            var query = from cus in mainDbContext.Customer
                        where cus.CustomerId == customerId
                        select cus;

            result = query.SingleOrDefault();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public List<Customer> GetByIsDeleted(bool isDeleted)
        {
            List<Customer> result = null;

            var query = from cus in mainDbContext.Customer
                        where cus.IsDeleted == isDeleted
                        select cus;

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int Update(Customer Customer)
        {
            int rowAffected = 0;

            mainDbContext.Update(Customer);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int Insert(Customer Customer)
        {
            int rowAffected = 0;

            mainDbContext.Add(Customer);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CustomerId"></param>
        /// <returns></returns>
        public Customer DeleteByCustomerId(int CustomerId)
        {
            Customer result = null;

            var query = from customer in mainDbContext.Customer
                        where customer.CustomerId == CustomerId
                        select customer;

            var tempCustomer = query.SingleOrDefault();
            if (tempCustomer != null)
            {
                tempCustomer.IsDeleted = true;

                mainDbContext.Update(tempCustomer);
                var rowAffected = mainDbContext.SaveChanges();
                if (rowAffected > 0)
                    result = tempCustomer;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion

    }
}
