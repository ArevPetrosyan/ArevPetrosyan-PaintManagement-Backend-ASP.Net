﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace PaintManagement.DataAccess
{
    public class WorkProcessDataAccess
    {

        #region [ Constructor(s) ]

        public WorkProcessDataAccess(MainDBContext dbContext, bool startNewTransaction = false)
        {
            if (dbContext != null)
                this.mainDbContext = dbContext;
            else
            {
                this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
                if (startNewTransaction)
                {
                    _transaction = this.mainDbContext.Database.BeginTransaction();
                }
            }
        }

        #endregion

        #region [ Public Property(s) ]

        public MainDBContext MainDbContext { get => mainDbContext; }

        #endregion

        #region [ Public Method(s) ]

        public List<WorkProcess> GetAllWorkProcess()
        {
            List<WorkProcess> result = null;

            var query = from workprocess in mainDbContext.WorkProcess.Include("WorkProcessSteps.Paint")

                        join orderItem in mainDbContext.OrderItem.Include("WorkPiece").Include("Order")
                            on workprocess.OrderItemId equals orderItem.OrderItemId

                        join order in mainDbContext.Order
                            on orderItem.OrderId equals order.OrderId

                        join workpiece in mainDbContext.WorkPiece
                            on orderItem.WorkPieceId equals workpiece.WorkPieceId

                        join staff in mainDbContext.Staff
                            on workprocess.StaffId equals staff.StaffId

                        select new WorkProcess
                        {
                            StaffId = staff.StaffId,
                            CreateDate = workprocess.CreateDate,
                            IsDeleted = workprocess.IsDeleted,
                            OrderItem = orderItem,
                            Amount = workprocess.Amount,
                            OrderItemId = workprocess.OrderItemId,
                            Staff = staff,
                            StatusId = workprocess.StatusId,
                            WorkProcessSteps = workprocess.WorkProcessSteps,
                            WorkProcessId = workprocess.WorkProcessId,
                            WorkProcessStartDate = workprocess.WorkProcessStartDate
                        };

            result = query.ToList();

            return result;
        }

        public WorkProcess GetById(int workProcessId)
        {
            WorkProcess result = null;

            var query = from workprocess in mainDbContext.WorkProcess.Include("WorkProcessSteps.Paint")
                        join orderItem in mainDbContext.OrderItem.Include("WorkPiece").Include("Order")
                            on workprocess.OrderItemId equals orderItem.OrderItemId
                        join staff in mainDbContext.Staff
                            on workprocess.StaffId equals staff.StaffId

                        where workprocess.WorkProcessId == workProcessId

                        select new WorkProcess
                        {
                            StaffId = staff.StaffId,
                            CreateDate = workprocess.CreateDate,
                            IsDeleted = workprocess.IsDeleted,
                            OrderItem = orderItem,
                            Amount = workprocess.Amount,
                            OrderItemId = workprocess.OrderItemId,
                            Staff = staff,
                            StatusId = workprocess.StatusId,
                            WorkProcessSteps = workprocess.WorkProcessSteps,
                            WorkProcessId = workprocess.WorkProcessId,
                            WorkProcessStartDate = workprocess.WorkProcessStartDate
                        };

            result = query.SingleOrDefault();

            return result;
        }

        public WorkProcess GetByWorkProcessStepId(int workProcessStepId)
        {
            WorkProcess result = null;

            var query = from workprocess in mainDbContext.WorkProcess.Include("WorkProcessSteps.Paint")
                        join workProcessStep in mainDbContext.WorkProcessStep
                            on workprocess.WorkProcessId equals workProcessStep.WorkProcessId
                        join orderItem in mainDbContext.OrderItem.Include("WorkPiece").Include("Order")
                            on workprocess.OrderItemId equals orderItem.OrderItemId
                        join staff in mainDbContext.Staff
                            on workprocess.StaffId equals staff.StaffId

                        where workProcessStep.WorkProcessStepId == workProcessStepId

                        select new WorkProcess
                        {
                            StaffId = staff.StaffId,
                            CreateDate = workprocess.CreateDate,
                            IsDeleted = workprocess.IsDeleted,
                            OrderItem = orderItem,
                            Amount = workprocess.Amount,
                            OrderItemId = workprocess.OrderItemId,
                            Staff = staff,
                            StatusId = workprocess.StatusId,
                            WorkProcessSteps = workprocess.WorkProcessSteps,
                            WorkProcessId = workprocess.WorkProcessId,
                            WorkProcessStartDate = workprocess.WorkProcessStartDate
                        };

            result = query.SingleOrDefault();

            return result;
        }

        public int Insert(WorkProcess workProcess)
        {
            int rowAffected = 0;

            mainDbContext.Add(workProcess);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Update(WorkProcess workProcess)
        {
            int rowAffected = 0;

            mainDbContext.Update(workProcess);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public WorkProcess DeleteByWorkProcessId(int workProcessId)
        {
            WorkProcess result = null;

            //TODO: Should call storprocedure for it

            var query = from workprocess in mainDbContext.WorkProcess
                        where workprocess.WorkProcessId == workProcessId
                        select workprocess;

            var tempWorkProcess = query.SingleOrDefault();
            if (tempWorkProcess != null)
            {
                tempWorkProcess.IsDeleted = true;

                mainDbContext.Update(tempWorkProcess);
                var rowAffected = mainDbContext.SaveChanges();

                if (rowAffected > 0)
                    result = tempWorkProcess;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;
        private readonly IDbContextTransaction _transaction = null;

        #endregion

    }
}
