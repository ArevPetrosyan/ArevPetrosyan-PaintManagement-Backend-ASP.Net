﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class StaffDataAccess
    {
        #region [ Constructor(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mainDbContext"></param>
        public StaffDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        public Staff GetById(int staffId)
        {
            Staff result = null;

            var query = from staff in mainDbContext.Staff
                        where staff.StaffId == staffId
                        select staff;

            result = query.SingleOrDefault();

            return result;
        }

        public List<Staff> GetAllStaffByIsDeleted(bool isDeleted)
        {
            List<Staff> resultList = null;

            var query = from staff in mainDbContext.Staff
                        where staff.IsDeleted == isDeleted
                        select staff;

            resultList = query.ToList();

            return resultList;
        }

        public Staff GetByAuthenticationBarcode(string authenticationBarcode)
        {
            Staff temp = null;

            var query = from staff in mainDbContext.Staff
                        where staff.AuthenticationBarcode == authenticationBarcode
                        select staff;

            temp = query.SingleOrDefault();

            return temp;
        }

        public Staff GetByAuthenticationTagId(string authenticationTagId)
        {
            Staff temp = null;

            var query = from staff in mainDbContext.Staff
                        where staff.AuthenticationTagId == authenticationTagId
                        select staff;

            temp = query.SingleOrDefault();

            return temp;
        }

        public int Insert(Staff staff)
        {
            int rowAffected = 0;

            mainDbContext.Add(staff);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Update(Staff staff)
        {
            int rowAffected = 0;

            mainDbContext.Update(staff);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public Staff DeleteByStaffId(int staffId)
        {
            Staff result = null;

            //TODO: Should call storprocedure for it
            var tempStaff = GetById(staffId);
            if (tempStaff != null)
            {
                tempStaff.IsDeleted = true;

                mainDbContext.Update(tempStaff);
                var rowAffected = mainDbContext.SaveChanges();
                if (rowAffected > 0)
                    result = tempStaff;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion
    }
}
