﻿using PaintManagement.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using PaintManagement.Common.Models.DB;
using PaintManagement.Common.Models.DB.Views;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;

namespace PaintManagement.DataAccess
{
    public class BucketDataAccess
    {
        #region [ Constructor(s) ]

        public BucketDataAccess(MainDBContext dbContext, bool startNewTransaction = false)
        {
            if (dbContext != null)
                this.mainDbContext = dbContext;
            else
            {
                this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
                if (startNewTransaction)
                {
                    _transaction = this.mainDbContext.Database.BeginTransaction();
                }
            }
        }

        #endregion

        #region [ Public Property(s) ]

        public MainDBContext MainDbContext { get => mainDbContext; }

        #endregion

        #region [ Public Method(s) ]

        public List<BucketView> GetByBestBefore_IsDeleted_IsEmpty_RemainDays(int remainDays, bool isDeleted, bool isEmpty)
        {
            List<BucketView> resultList = null;

            var query = from bucket in mainDbContext.Bucket
                        join paint in mainDbContext.Paint
                         on bucket.PaintId equals paint.PaintId
                        join supplier in mainDbContext.Supplier
                        on paint.SupplierId equals supplier.SupplierId
                        where bucket.IsDeleted == isDeleted && bucket.IsEmpty == isEmpty
                       && bucket.BestBefore < DateTime.Today.AddDays(remainDays)
                        select new BucketView
                        {
                            BucketId = bucket.BucketId,
                            Amount = bucket.Amount,
                            Barcode = bucket.Barcode,
                            BestBefore = bucket.BestBefore,
                            ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                            ProductionDate = bucket.ProductionDate,
                            RemainingAmount = bucket.RemainingAmount,
                            PaintName = paint.PaintName,
                            PaintId = bucket.PaintId,
                            PaintTypeId = paint.PaintTypeId,
                            SupplierId = paint.SupplierId,
                            SupplierName = supplier.SupplierName,
                        };

            resultList = query.ToList();

            return resultList;
        }

        public List<Bucket> GetBucketByBatchId(int batchId)
        {
            List<Bucket> tempList = null;

            var query = from bucket in mainDbContext.Bucket
                        join batchItem in mainDbContext.BatchItem
                            on bucket.BucketId equals batchItem.BucketId
                        where batchItem.BatchId == batchId

                        select new Bucket
                        {
                            BucketId = bucket.BucketId,
                            Amount = bucket.Amount,
                            Barcode = bucket.Barcode,
                            BestBefore = bucket.BestBefore,
                            IsDeleted = bucket.IsDeleted,
                            IsEmpty = bucket.IsEmpty,
                            ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                            Paint = bucket.Paint,
                            PaintId = bucket.PaintId,
                            ProductionDate = bucket.ProductionDate,
                            RemainingAmount = bucket.RemainingAmount
                        };

            tempList = query.ToList();

            return tempList;
        }

        public Bucket GetByBucketId(int bucketId)
        {
            Bucket temp = null;

            var query = from bucket in mainDbContext.Bucket
                        join paint in mainDbContext.Paint
                        on bucket.PaintId equals paint.PaintId
                        where bucket.BucketId == bucketId
                        select new Bucket
                        {
                            BucketId = bucket.BucketId,
                            Amount = bucket.Amount,
                            Barcode = bucket.Barcode,
                            BestBefore = bucket.BestBefore,
                            IsDeleted = bucket.IsDeleted,
                            IsEmpty = bucket.IsEmpty,
                            ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                            Paint = paint,
                            PaintId = bucket.PaintId,
                            ProductionDate = bucket.ProductionDate,
                            RemainingAmount = bucket.RemainingAmount
                        };

            temp = query.SingleOrDefault();

            return temp;
        }

        public Bucket GetByBarcode(string barcode)
        {
            Bucket temp = null;

            var query = from bucket in mainDbContext.Bucket
                        join paint in mainDbContext.Paint
                        on bucket.PaintId equals paint.PaintId
                        where bucket.Barcode == barcode
                        select new Bucket
                        {
                            BucketId = bucket.BucketId,
                            Amount = bucket.Amount,
                            Barcode = bucket.Barcode,
                            BestBefore = bucket.BestBefore,
                            IsDeleted = bucket.IsDeleted,
                            IsEmpty = bucket.IsEmpty,
                            ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                            Paint = paint,
                            PaintId = bucket.PaintId,
                            ProductionDate = bucket.ProductionDate,
                            RemainingAmount = bucket.RemainingAmount
                        };

            temp = query.SingleOrDefault();

            return temp;
        }

        public List<Bucket> GetBucketByPaintId_IsDeleted(int paintId, bool isDeleted)
        {
            List<Bucket> tempList = null;

            var query = from bucket in mainDbContext.Bucket
                        join paint in mainDbContext.Paint
                        on bucket.PaintId equals paint.PaintId
                        where bucket.PaintId == paintId
                        && bucket.IsDeleted == isDeleted
                        select new Bucket
                        {
                            BucketId = bucket.BucketId,
                            Amount = bucket.Amount,
                            Barcode = bucket.Barcode,
                            BestBefore = bucket.BestBefore,
                            IsDeleted = bucket.IsDeleted,
                            IsEmpty = bucket.IsEmpty,
                            ManufacturerBatchNumber = bucket.ManufacturerBatchNumber,
                            Paint = paint,
                            PaintId = bucket.PaintId,
                            ProductionDate = bucket.ProductionDate,
                            RemainingAmount = bucket.RemainingAmount
                        };

            tempList = query.ToList();

            return tempList;
        }

        public int Update(Bucket bucket)
        {
            int rowAffected = 0;

            mainDbContext.Update(bucket);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Insert(Bucket bucket)
        {
            int rowAffected = 0;

            mainDbContext.Add(bucket);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Insert(List<Bucket> buckets)
        {
            int rowAffected = 0;

            mainDbContext.AddRange(buckets);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public Bucket DeleteByBucketId(int bucketId)
        {
            Bucket result = null;

            var query = from bucket in mainDbContext.Bucket
                        where bucket.BucketId == bucketId
                        select bucket;

            var tempBucket = query.SingleOrDefault();
            if (tempBucket != null)
            {
                tempBucket.IsDeleted = true;

                mainDbContext.Update(tempBucket);
                var rowAffected = mainDbContext.SaveChanges();
                if (rowAffected > 0)
                    result = tempBucket;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;
        private readonly IDbContextTransaction _transaction = null;

        #endregion
    }
}
