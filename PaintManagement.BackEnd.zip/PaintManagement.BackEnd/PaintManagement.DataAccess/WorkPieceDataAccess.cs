﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class WorkPieceDataAccess
    {

        #region [ Constructor(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mainDbContext"></param>
        public WorkPieceDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<WorkPiece> GetAllWorkPiece()
        {
            List<WorkPiece> result = null;

            var query = from workPiece in mainDbContext.WorkPiece
                        join customer in mainDbContext.Customer
                        on workPiece.CustomerId equals customer.CustomerId
                        select new WorkPiece
                        {
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            IsDeleted = workPiece.IsDeleted,
                            WorkPieceDescription = workPiece.WorkPieceDescription,
                            WorkPieceId = workPiece.WorkPieceId,
                            WorkPieceName = workPiece.WorkPieceName
                        };

            result = query.ToList();

            return result;
        }

        public WorkPiece GetById(int workPieceId)
        {
            WorkPiece result = null;

            var query = from workPiece in mainDbContext.WorkPiece
                        join customer in mainDbContext.Customer
                        on workPiece.CustomerId equals customer.CustomerId
                        where workPiece.WorkPieceId == workPieceId
                        select new WorkPiece
                        {
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            IsDeleted = workPiece.IsDeleted,
                            WorkPieceDescription = workPiece.WorkPieceDescription,
                            WorkPieceId = workPiece.WorkPieceId,
                            WorkPieceName = workPiece.WorkPieceName
                        };

            result = query.SingleOrDefault();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<WorkPiece> GetByIsDeleted(bool isDeleted)
        {
            List<WorkPiece> result = null;

            var query = from workPiece in mainDbContext.WorkPiece
                        join customer in mainDbContext.Customer
                        on workPiece.CustomerId equals customer.CustomerId
                        where workPiece.IsDeleted == isDeleted
                        && customer.IsDeleted == isDeleted
                        select new WorkPiece
                        {
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            IsDeleted = workPiece.IsDeleted,
                            WorkPieceDescription = workPiece.WorkPieceDescription,
                            WorkPieceId = workPiece.WorkPieceId,
                            WorkPieceName = workPiece.WorkPieceName
                        };

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<WorkPiece> GetByCustomerId_IsDeleted(int customerId, bool isDeleted)
        {
            List<WorkPiece> result = null;

            var query = from workPiece in mainDbContext.WorkPiece
                        join customer in mainDbContext.Customer
                        on workPiece.CustomerId equals customer.CustomerId
                        where workPiece.CustomerId == customerId
                                && workPiece.IsDeleted == isDeleted
                        select new WorkPiece
                        {
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            IsDeleted = workPiece.IsDeleted,
                            WorkPieceDescription = workPiece.WorkPieceDescription,
                            WorkPieceId = workPiece.WorkPieceId,
                            WorkPieceName = workPiece.WorkPieceName
                        };

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workPiece"></param>
        /// <returns></returns>
        public int Insert(WorkPiece workPiece)
        {
            int rowAffected = 0;

            mainDbContext.Add(workPiece);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workPiece"></param>
        /// <returns></returns>
        public int Update(WorkPiece workPiece)
        {
            int rowAffected = 0;

            mainDbContext.Update(workPiece);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public WorkPiece DeleteByWorkPieceId(int workPieceId)
        {
            WorkPiece result = null;

            var query = from workPiece in mainDbContext.WorkPiece
                        where workPiece.WorkPieceId == workPieceId
                        select workPiece;

            var tempWorkPiece = query.SingleOrDefault();
            if (tempWorkPiece != null)
            {
                tempWorkPiece.IsDeleted = true;

                mainDbContext.Update(tempWorkPiece);
                var rowAffected = mainDbContext.SaveChanges();

                if (rowAffected > 0)
                    result = tempWorkPiece;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion

    }
}
