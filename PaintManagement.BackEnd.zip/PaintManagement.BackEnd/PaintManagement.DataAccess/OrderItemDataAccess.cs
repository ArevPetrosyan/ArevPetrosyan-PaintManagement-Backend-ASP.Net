﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class OrderItemDataAccess
    {

        #region [ Constructor(s) ]

        public OrderItemDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        public List<OrderItem> GetOrderItemByOrderId(int orderId)
        {
            List<OrderItem> tempResultList = null;

            var query = from orderItem in mainDbContext.OrderItem
                        join workPiece in mainDbContext.WorkPiece
                        on orderItem.WorkPieceId equals workPiece.WorkPieceId
                        join paint in mainDbContext.Paint
                        on orderItem.PaintId equals paint.PaintId
                        select new OrderItem
                        {
                            OrderItemId = orderItem.OrderItemId,
                            OrderId = orderItem.OrderId,
                            Amount = orderItem.Amount,
                            PaintId = orderItem.PaintId,
                            Paint = paint,
                            WorkPieceId = orderItem.WorkPieceId,
                            WorkPiece = workPiece
                        };

            tempResultList = query.ToList();

            return tempResultList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public int DeleteByOrderItemId(int orderItemId)
        {
            int rowAffected = 0;

            var query = from orderItem in mainDbContext.OrderItem
                        where orderItem.OrderItemId == orderItemId
                        select orderItem;

            var tempOrderItem = query.SingleOrDefault();
            if (tempOrderItem != null)
            {
                mainDbContext.Remove(tempOrderItem);
                rowAffected = mainDbContext.SaveChanges();
            }

            return rowAffected;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion
    }
}
