﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class PaintM2MDataAccess
    {
        #region [ Constructor(s) ]

        public PaintM2MDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        public int InsertPaintM2M(PaintM2M paintM2M)
        {
            int rowAffected = 0;

            mainDbContext.Add(paintM2M);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int DeletePaintM2M(PaintM2M paintM2M)
        {
            int rowAffected = 0;

            var query = from paintm2m in mainDbContext.PaintM2M
                        where paintm2m.MainPaintId == paintM2M.MainPaintId
                           && paintm2m.ConnectedPaintId == paintM2M.ConnectedPaintId
                        select paintm2m;

            var tempPaint = query.SingleOrDefault();

            if (tempPaint != null)
            {
                mainDbContext.Remove(tempPaint);
                rowAffected = mainDbContext.SaveChanges();
            }

            return rowAffected;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion
    }
}
