﻿using PaintManagement.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PaintManagement.DataAccess
{
    public class WorkProcessStepDataAccess
    {

        #region [ Constructor(s) ]

        public WorkProcessStepDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public int DeleteByWorkProcessStepId(int workProcessStepId)
        {
            int rowAffected = 0;

            var query = from workprocessStep in mainDbContext.WorkProcessStep
                        where workprocessStep.WorkProcessStepId == workProcessStepId
                        select workprocessStep;

            var tempWorkProcessStep = query.SingleOrDefault();
            if (tempWorkProcessStep != null)
            {
                mainDbContext.Remove(tempWorkProcessStep);
                rowAffected = mainDbContext.SaveChanges();
            }

            return rowAffected;
        }

        #endregion


        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion
    }
}
