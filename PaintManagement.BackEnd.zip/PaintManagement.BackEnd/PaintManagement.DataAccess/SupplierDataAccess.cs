﻿using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using PaintManagement.Common;

namespace PaintManagement.DataAccess
{
    public class SupplierDataAccess
    {

        #region [ Constructor(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mainDbContext"></param>
        public SupplierDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Supplier> GetAllSupplier()
        {
            List<Supplier> result = null;

            var query = from sup in mainDbContext.Supplier
                        select sup;

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public List<Supplier> GetByIsDeleted(bool isDeleted)
        {
            List<Supplier> result = null;

            var query = from sup in mainDbContext.Supplier
                        where sup.IsDeleted == isDeleted
                        select sup;

            result = query.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public Supplier GetById(int supplierId)
        {
            Supplier result = null;

            var query = from sup in mainDbContext.Supplier
                        where sup.SupplierId == supplierId
                        select sup;

            result = query.SingleOrDefault();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int Update(Supplier supplier)
        {
            int rowAffected = 0;

            mainDbContext.Update(supplier);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int Insert(Supplier supplier)
        {
            int rowAffected = 0;

            mainDbContext.Add(supplier);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public Supplier DeleteBySupplierId(int supplierId)
        {
            Supplier result = null;

            var query = from supplier in mainDbContext.Supplier
                        where supplier.SupplierId == supplierId
                        select supplier;

            var tempSupplier = query.SingleOrDefault();
            if (tempSupplier != null)
            {
                tempSupplier.IsDeleted = true;

                mainDbContext.Update(tempSupplier);
                var rowAffected = mainDbContext.SaveChanges();

                if (rowAffected > 0)
                    result = tempSupplier;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion

    }
}
