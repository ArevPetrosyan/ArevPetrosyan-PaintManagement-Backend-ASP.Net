﻿using PaintManagement.Common;
using PaintManagement.Common.Models.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace PaintManagement.DataAccess
{
    public class OrderDataAccess
    {
        #region [ Constructor(s) ]

        public OrderDataAccess()
        {
            this.mainDbContext = new MainDBContext(GeneralParameter.ConnectionString);
        }

        #endregion

        #region [ Public Method(s) ]

        public Order GetOrderById(int orderId)
        {
            Order tempOrder = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.OrderId == orderId
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrder = query.SingleOrDefault();

            return tempOrder;
        }

        public List<Order> GetOrderByIsDeleted(bool isDeleted)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.IsDeleted == isDeleted
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public List<Order> GetOrderByCustomerId(int customerId)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.CustomerId == customerId
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public List<Order> GetOrderByCustomerId_IsDeleted(int customerId, bool isDeleted)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.CustomerId == customerId &&
                        order.IsDeleted == isDeleted
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public List<Order> GetOrderByOrderStatusId_IsDeleted(int orderStatusId, bool isDeleted)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.OrderStatusId == orderStatusId
                        && order.IsDeleted == isDeleted
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public List<Order> GetOrderByWorkPieceId_IsDeleted(int workpieceId, bool isDeleted)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join orderItem in mainDbContext.OrderItem
                        on order.OrderId equals orderItem.OrderId
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.IsDeleted == isDeleted &&
                        orderItem.WorkPieceId == workpieceId
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public List<Order> GetOrderByPaintId_IsDeleted(int paintId, bool isDeleted)
        {
            List<Order> tempOrderList = null;

            var query = from order in mainDbContext.Order.Include("OrderItems.WorkPiece").Include("OrderItems.Paint")
                        join orderItem in mainDbContext.OrderItem
                        on order.OrderId equals orderItem.OrderId
                        join customer in mainDbContext.Customer
                        on order.CustomerId equals customer.CustomerId
                        where order.IsDeleted == isDeleted &&
                        orderItem.PaintId == paintId
                        select new Order
                        {
                            CreateDate = order.CreateDate,
                            Customer = customer,
                            CustomerId = customer.CustomerId,
                            DeliveryDate = order.DeliveryDate,
                            IsDeleted = order.IsDeleted,
                            OrderCode = order.OrderCode,
                            OrderId = order.OrderId,
                            OrderStatusId = order.OrderStatusId,
                            OrderItems = order.OrderItems
                        };

            tempOrderList = query.ToList();

            return tempOrderList;
        }

        public int Insert(Order order)
        {
            int rowAffected = 0;

            mainDbContext.Add(order);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public int Update(Order order)
        {
            int rowAffected = 0;

            mainDbContext.Update(order);
            rowAffected = mainDbContext.SaveChanges();

            return rowAffected;
        }

        public Order DeleteByOrderId(int orderId)
        {
            Order result = null;

            var query = from order in mainDbContext.Order
                        where order.OrderId == orderId
                        select order;

            var tempOrder = query.SingleOrDefault();
            if (tempOrder != null)
            {
                tempOrder.IsDeleted = true;

                mainDbContext.Update(tempOrder);
               var rowAffected = mainDbContext.SaveChanges();
                if (rowAffected > 0)
                    result = tempOrder;
            }

            return result;
        }

        #endregion

        #region [ Private Field(s) ]

        private MainDBContext mainDbContext = null;

        #endregion
    }
}
